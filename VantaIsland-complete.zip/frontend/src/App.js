import "@/App.css";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { Toaster } from "@/components/ui/sonner";
import Nav from "@/components/vanta/Nav";
import Hero from "@/components/vanta/Hero";
import Features from "@/components/vanta/Features";
import Gallery from "@/components/vanta/Gallery";
import Pricing from "@/components/vanta/Pricing";
import Download from "@/components/vanta/Download";
import Footer from "@/components/vanta/Footer";
import { PaymentSuccess, PaymentCancel } from "@/components/vanta/PaymentPages";

const Landing = () => (
  <>
    <Nav />
    <Hero />
    <Features />
    <Gallery />
    <Pricing />
    <Download />
    <Footer />
  </>
);

function App() {
  return (
    <div className="App grain min-h-screen bg-[#060709]">
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Landing />} />
          <Route path="/payment/success" element={<PaymentSuccess />} />
          <Route path="/payment/cancel" element={<PaymentCancel />} />
        </Routes>
      </BrowserRouter>
      <Toaster theme="dark" position="bottom-right" />
    </div>
  );
}

export default App;
