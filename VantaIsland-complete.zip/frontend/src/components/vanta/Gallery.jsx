import { useEffect, useState, useCallback } from "react";
import { Lock, Upload, KeyRound } from "lucide-react";
import { toast } from "sonner";
import { Dialog, DialogContent, DialogTitle } from "@/components/ui/dialog";
import { http, getLicense, setLicense, startCheckout } from "@/lib/api";

const TABS = [["all", "All"], ["nature", "Nature"], ["city", "City"], ["space", "Space"], ["abstract", "Abstract"]];

function Card({ w, onOpen }) {
  const [hover, setHover] = useState(false);
  return (
    <button data-testid="wallpaper-card-item" onClick={() => onOpen(w)} onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)}
      className="group text-left rounded-2xl overflow-hidden border border-white/[0.08] bg-[#0C0E12] hover:border-white/25 transition-colors duration-300">
      <div className="relative aspect-[16/10] bg-black overflow-hidden">
        <img src={w.preview_image} alt={w.title} loading="lazy" className="absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" />
        {hover && <video src={w.preview_video} autoPlay muted loop playsInline className="absolute inset-0 w-full h-full object-cover" />}
        {w.locked && <div className="absolute inset-0 bg-black/40 flex items-center justify-center"><Lock size={20} /></div>}
      </div>
      <div className="flex items-center justify-between px-4 py-3">
        <div className="min-w-0">
          <p className="font-medium text-sm truncate">{w.title}</p>
          <p className="text-[11px] text-zinc-500 capitalize">{w.category} · {w.source}</p>
        </div>
        <span className={`font-mono text-[10px] px-2 py-0.5 rounded-full ${w.premium ? "bg-amber-400/15 text-amber-400" : "bg-emerald-400/15 text-emerald-400"}`}>{w.premium ? "PLUS" : "FREE"}</span>
      </div>
    </button>
  );
}

function ImportZone() {
  const [url, setUrl] = useState(null);
  const onFile = (f) => f && setUrl({ src: URL.createObjectURL(f), video: f.type.startsWith("video") });
  return (
    <label data-testid="wallpaper-import-dropzone" onDragOver={(e) => e.preventDefault()} onDrop={(e) => { e.preventDefault(); onFile(e.dataTransfer.files[0]); }}
      className="relative flex flex-col items-center justify-center h-full min-h-[220px] rounded-2xl border border-dashed border-white/20 hover:border-amber-400/60 cursor-pointer overflow-hidden transition-colors duration-300">
      {url ? (url.video ? <video src={url.src} autoPlay muted loop playsInline className="absolute inset-0 w-full h-full object-cover" /> : <img src={url.src} alt="" className="absolute inset-0 w-full h-full object-cover" />) : (
        <><Upload size={20} className="text-zinc-400" /><p className="text-sm mt-3 font-medium">Preview your own wallpaper</p>
          <p className="text-[11px] text-zinc-500 mt-1 px-6 text-center">Drop an MP4, MOV or image. Import it in the app for real.</p></>
      )}
      <input type="file" accept="video/*,image/*" className="hidden" data-testid="wallpaper-import-input" onChange={(e) => onFile(e.target.files[0])} />
    </label>
  );
}

export default function Gallery() {
  const [cat, setCat] = useState("all");
  const [data, setData] = useState({ items: [], unlocked: false });
  const [loading, setLoading] = useState(true);
  const [open, setOpen] = useState(null);
  const [key, setKey] = useState(getLicense());

  const load = useCallback(async () => {
    setLoading(true);
    const { data } = await http.get("/wallpapers", { params: { category: cat, license: getLicense() || undefined } });
    setData(data);
    setLoading(false);
  }, [cat]);

  useEffect(() => { load(); }, [load]);

  const activate = async () => {
    const { data } = await http.get("/license/verify", { params: { key } });
    if (data.valid) { setLicense(data.key); toast.success("Vanta Plus unlocked"); load(); }
    else toast.error("That license key isn't valid");
  };

  return (
    <section id="wallpapers" className="py-28 bg-[#0A0B0E] border-y border-white/[0.06]">
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex flex-wrap items-end justify-between gap-6">
          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.2em] text-amber-400/90">Wallpaper store</p>
            <h2 className="font-display text-3xl lg:text-5xl font-bold tracking-tight mt-3">Desktops that never sit still.</h2>
            <p className="text-zinc-400 mt-3 max-w-lg">Free stock video loops, applied in one click inside the app. <span data-testid="wallpaper-count">{data.items.length}</span> in this view.</p>
          </div>
          <div className="flex gap-1.5 flex-wrap">
            {TABS.map(([id, l]) => (
              <button key={id} data-testid={`wallpaper-tab-${id}`} onClick={() => setCat(id)}
                className={`text-sm px-4 py-1.5 rounded-full border transition-colors duration-200 ${cat === id ? "bg-white text-black border-white" : "border-white/10 text-zinc-400 hover:text-white"}`}>{l}</button>
            ))}
          </div>
        </div>

        <div className="mt-6 flex flex-wrap items-center gap-2 text-sm">
          {data.unlocked ? <span data-testid="wallpaper-plus-active" className="text-emerald-400 font-medium">Vanta Plus active — full library unlocked</span> : (
            <>
              <KeyRound size={15} className="text-zinc-500" />
              <input data-testid="wallpaper-license-input" value={key} onChange={(e) => setKey(e.target.value)} placeholder="VANTA-XXXX-XXXX-XXXX-XXXX"
                className="font-mono text-xs bg-transparent border border-white/10 rounded-full px-4 py-1.5 w-64 focus:outline-none focus:border-amber-400/60" />
              <button data-testid="wallpaper-license-activate-btn" onClick={activate} className="text-xs rounded-full border border-white/15 px-4 py-1.5 hover:border-white/40">Unlock</button>
            </>
          )}
        </div>

        <div className="mt-8 grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {cat === "all" && <ImportZone />}
          {loading ? Array.from({ length: 7 }).map((_, i) => <div key={i} className="aspect-[16/12] rounded-2xl bg-white/[0.04] animate-pulse" />)
            : data.items.map((w) => <Card key={w.id} w={w} onOpen={setOpen} />)}
        </div>
      </div>

      <Dialog open={!!open} onOpenChange={(o) => !o && setOpen(null)}>
        <DialogContent data-testid="wallpaper-preview-modal" className="max-w-4xl bg-[#0C0E12] border-white/10 text-white p-0 overflow-hidden">
          {open && (
            <>
              <video src={open.video_url || open.preview_video} autoPlay muted loop playsInline className="w-full aspect-video object-cover bg-black" />
              <div className="flex flex-wrap items-center justify-between gap-4 p-6">
                <div>
                  <DialogTitle className="font-display text-2xl">{open.title}</DialogTitle>
                  <p className="text-sm text-zinc-400 capitalize">{open.category} · {open.source}</p>
                </div>
                {open.locked ? (
                  <button data-testid="wallpaper-modal-upgrade-btn" onClick={startCheckout} className="rounded-full bg-amber-400 text-black font-semibold px-5 py-2.5 hover:bg-amber-300">Unlock with Vanta Plus · $1.99/mo</button>
                ) : (
                  <a data-testid="wallpaper-modal-download-btn" href={open.video_url} target="_blank" rel="noreferrer" className="rounded-full bg-white text-black font-semibold px-5 py-2.5 hover:bg-amber-400">Open full quality</a>
                )}
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </section>
  );
}
