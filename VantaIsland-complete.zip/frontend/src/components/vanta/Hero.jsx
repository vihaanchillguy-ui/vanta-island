import { useState } from "react";
import { Download, ArrowRight } from "lucide-react";
import IslandSimulator from "./IslandSimulator";

const STATES = [["compact", "Compact"], ["music", "Now Playing"], ["battery", "Charging"], ["weather", "Weather & Calendar"], ["volume", "Volume HUD"]];

export default function Hero() {
  const [state, setState] = useState("music");
  const [theme, setTheme] = useState("obsidian");

  return (
    <section id="island" className="relative pt-28 pb-20 grid-lines">
      <div className="max-w-7xl mx-auto px-6 grid lg:grid-cols-[1fr_1.15fr] gap-14 items-center">
        <div className="rise">
          <p className="text-xs font-semibold uppercase tracking-[0.2em] text-amber-400/90 mb-5">Native macOS · SwiftUI · Free</p>
          <h1 className="font-display text-5xl lg:text-7xl font-black tracking-tight leading-[0.95]">
            The island<br />your Mac<br /><span className="text-zinc-500">was missing.</span>
          </h1>
          <p className="mt-7 text-lg text-zinc-300 leading-relaxed max-w-md">
            Vanta Island turns the top of your screen into a living Dynamic Island — music, battery, weather, calendar and system HUDs — plus endlessly animated wallpapers.
          </p>
          <div className="mt-9 flex flex-wrap gap-3">
            <a href="#download" data-testid="hero-download-dmg-btn" className="flex items-center gap-2 rounded-full bg-white text-black font-semibold px-6 py-3 hover:bg-amber-400 hover:-translate-y-0.5 transition-[background-color,transform] duration-200">
              <Download size={17} /> Build the DMG
            </a>
            <a href="#wallpapers" data-testid="hero-explore-wallpapers-btn" className="flex items-center gap-2 rounded-full border border-white/15 px-6 py-3 hover:border-white/40 transition-colors duration-200">
              Explore wallpapers <ArrowRight size={16} />
            </a>
          </div>
        </div>

        <div className="rise" style={{ animationDelay: "0.15s" }}>
          <div className="relative rounded-2xl overflow-hidden border border-white/10 shadow-[0_40px_120px_rgba(0,0,0,0.8)] aspect-[16/10] bg-black">
            <video src="https://assets.mixkit.co/videos/4040/4040-720.mp4" autoPlay muted loop playsInline className="absolute inset-0 w-full h-full object-cover opacity-80" />
            <div className="absolute top-0 inset-x-0 h-7 bg-black/40 backdrop-blur-md flex items-center justify-between px-4 text-[11px] text-white/80">
              <span className="font-semibold">Finder&nbsp;&nbsp; File&nbsp;&nbsp; Edit&nbsp;&nbsp; View</span><span>Wed 9:41</span>
            </div>
            <div className="absolute top-1.5 inset-x-0 flex justify-center z-10">
              <IslandSimulator state={state} theme={theme} />
            </div>
          </div>
          <div className="mt-5 flex flex-wrap items-center justify-between gap-3">
            <div className="flex flex-wrap gap-1.5">
              {STATES.map(([id, label]) => (
                <button key={id} data-testid={`island-state-${id}`} onClick={() => setState(id)}
                  className={`text-xs px-3 py-1.5 rounded-full border transition-colors duration-200 ${state === id ? "bg-white text-black border-white" : "border-white/10 text-zinc-400 hover:text-white"}`}>
                  {label}
                </button>
              ))}
            </div>
            <div className="flex rounded-full border border-white/10 p-0.5 text-xs">
              {[["obsidian", "Black Pill"], ["glass", "Glass"]].map(([id, label]) => (
                <button key={id} data-testid={`island-theme-toggle-${id}`} onClick={() => setTheme(id)}
                  className={`px-3 py-1 rounded-full transition-colors duration-200 ${theme === id ? "bg-amber-400 text-black font-semibold" : "text-zinc-400"}`}>
                  {label}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
