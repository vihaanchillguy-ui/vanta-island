import { useState } from "react";
import { Download as DIcon, Copy, Terminal, HardDrive } from "lucide-react";
import { toast } from "sonner";
import { API } from "@/lib/api";

const CMD = `unzip VantaIsland-macOS-source.zip -d VantaIsland
cd VantaIsland/VantaIsland
chmod +x build_dmg.sh && ./build_dmg.sh
open build/VantaIsland-1.0.0.dmg`;

const STEPS = ["Download the source package below.", "Run build_dmg.sh on your Mac (Xcode 15+, macOS 14+).", "Open the DMG and drag Vanta Island into Applications.", "Launch it, then allow Automation, Calendar & Location when asked."];

export default function Download() {
  const [tab, setTab] = useState("install");
  return (
    <section id="download" className="py-28 bg-[#0A0B0E] border-t border-white/[0.06]">
      <div className="max-w-7xl mx-auto px-6 grid lg:grid-cols-2 gap-14 items-start">
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.2em] text-amber-400/90">Download</p>
          <h2 className="font-display text-3xl lg:text-5xl font-bold tracking-tight mt-3">Built natively. Shipped as a DMG.</h2>
          <p className="text-zinc-400 mt-4 max-w-md">Vanta Island is a SwiftUI app for macOS 14 Sonoma and later, universal for Apple Silicon and Intel.</p>
          <a href={`${API}/download/source`} data-testid="dmg-download-primary-btn"
            className="mt-9 inline-flex items-center gap-2 rounded-full bg-white text-black font-semibold px-6 py-3 hover:bg-amber-400 transition-colors">
            <DIcon size={17} /> Download macOS package (.zip)
          </a>
          <div className="mt-10 flex items-center gap-5 rounded-2xl border border-white/[0.08] bg-[#0C0E12] p-6 max-w-md">
            <img src="/app-icon.jpg" alt="Vanta Island icon" className="w-16 h-16 rounded-2xl" />
            <div className="flex-1 border-t border-dashed border-white/20" />
            <div className="w-16 h-16 rounded-2xl bg-white/[0.06] flex items-center justify-center"><HardDrive className="text-zinc-400" /></div>
          </div>
          <p className="text-xs text-zinc-500 mt-3">Drag to Applications</p>
        </div>

        <div className="rounded-2xl border border-white/10 bg-[#0C0E12] overflow-hidden">
          <div className="flex items-center gap-2 px-4 h-10 border-b border-white/[0.08]">
            <span className="w-3 h-3 rounded-full bg-[#FF5F56]" /><span className="w-3 h-3 rounded-full bg-[#FFBD2E]" /><span className="w-3 h-3 rounded-full bg-[#27C93F]" />
            <div className="ml-4 flex gap-1 text-xs">
              {[["install", "Install"], ["build", "Build from Xcode"]].map(([id, l]) => (
                <button key={id} data-testid={id === "build" ? "dmg-xcode-tab-btn" : "dmg-install-tab-btn"} onClick={() => setTab(id)}
                  className={`px-3 py-1 rounded-md ${tab === id ? "bg-white/10 text-white" : "text-zinc-500"}`}>{l}</button>
              ))}
            </div>
          </div>
          {tab === "install" ? (
            <ol className="p-7 space-y-5">
              {STEPS.map((s, i) => (
                <li key={s} className="flex gap-4 text-sm text-zinc-300"><span className="font-mono text-amber-400">0{i + 1}</span>{s}</li>
              ))}
            </ol>
          ) : (
            <div className="p-7">
              <div className="flex items-center justify-between text-xs text-zinc-500 mb-3"><span className="flex items-center gap-2"><Terminal size={14} /> Terminal</span>
                <button data-testid="dmg-copy-cmd-btn" onClick={() => { navigator.clipboard.writeText(CMD); toast.success("Copied"); }} className="flex items-center gap-1 hover:text-white"><Copy size={13} /> Copy</button></div>
              <pre className="font-mono text-[13px] leading-7 text-emerald-300 whitespace-pre-wrap">{CMD}</pre>
              <p className="text-xs text-zinc-500 mt-5">Prefer Xcode? <span className="font-mono text-zinc-300">open Package.swift</span> and run the VantaIsland scheme. Set <span className="font-mono text-zinc-300">SIGN_ID</span> to sign with your Developer ID.</p>
            </div>
          )}
        </div>
      </div>
    </section>
  );
}
