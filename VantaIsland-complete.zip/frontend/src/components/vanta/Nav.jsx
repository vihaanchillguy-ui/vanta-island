import { Download } from "lucide-react";

const links = [
  ["Island", "#island"],
  ["Features", "#features"],
  ["Wallpapers", "#wallpapers"],
  ["Pricing", "#pricing"],
  ["Download", "#download"],
];

export default function Nav() {
  return (
    <header className="fixed top-0 inset-x-0 z-50 glass-panel border-x-0 border-t-0">
      <div className="max-w-7xl mx-auto px-6 h-14 flex items-center justify-between">
        <a href="#island" data-testid="navbar-brand" className="flex items-center gap-3">
          <img src="/app-icon.jpg" alt="Vanta Island" className="w-7 h-7 rounded-lg" />
          <span className="font-display font-bold tracking-tight">Vanta Island</span>
          <span className="hidden sm:block w-10 h-3 rounded-full bg-black border border-white/15" />
        </a>
        <nav className="hidden md:flex items-center gap-7 text-sm text-zinc-400">
          {links.map(([l, h]) => (
            <a key={h} href={h} data-testid={`nav-link-${l.toLowerCase()}`} className="hover:text-white transition-colors duration-200">{l}</a>
          ))}
        </nav>
        <a href="#download" data-testid="navbar-download-dmg-btn"
          className="flex items-center gap-2 rounded-full bg-white text-black text-sm font-semibold px-4 py-1.5 hover:bg-amber-400 transition-colors duration-200">
          <Download size={15} /> Get the DMG
        </a>
      </div>
    </header>
  );
}
