export default function Footer() {
  return (
    <footer className="pt-24 pb-10 overflow-hidden">
      <div className="max-w-7xl mx-auto px-6">
        <p className="font-display font-black tracking-tighter text-[18vw] leading-none text-white/[0.04] select-none">VANTA</p>
        <div className="mt-8 flex flex-wrap justify-between gap-4 text-xs text-zinc-500">
          <span>macOS 14 Sonoma or later · Apple Silicon & Intel</span>
          <span>Wallpapers: free stock video from Mixkit & Pexels. Weather by Open-Meteo.</span>
          <span>© {new Date().getFullYear()} Vanta Island</span>
        </div>
      </div>
    </footer>
  );
}
