import { useEffect, useState } from "react";
import { Link, useSearchParams } from "react-router-dom";
import { Copy, Loader2, CheckCircle2, XCircle } from "lucide-react";
import { toast } from "sonner";
import { http, setLicense } from "@/lib/api";

const Shell = ({ children }) => (
  <div className="min-h-screen flex items-center justify-center px-6 grid-lines">
    <div className="w-full max-w-lg rounded-3xl border border-white/10 bg-[#0C0E12] p-10 rise">{children}</div>
  </div>
);

export function PaymentSuccess() {
  const [params] = useSearchParams();
  const sessionId = params.get("session_id");
  const [state, setState] = useState({ phase: "checking", key: null });

  useEffect(() => {
    let tries = 0;
    let stop = false;
    const poll = async () => {
      if (stop) return;
      try {
        const { data } = await http.get(`/payments/status/${sessionId}`);
        if (data.payment_status === "paid" && data.license_key) {
          setLicense(data.license_key);
          return setState({ phase: "paid", key: data.license_key });
        }
        if (data.status === "expired") return setState({ phase: "failed" });
      } catch { /* retry */ }
      if (++tries >= 15) return setState({ phase: "timeout" });
      setTimeout(poll, 2000);
    };
    poll();
    return () => { stop = true; };
  }, [sessionId]);

  return (
    <Shell>
      <div data-testid="checkout-stripe-modal">
        {state.phase === "checking" && <p className="flex items-center gap-3 text-zinc-300"><Loader2 className="animate-spin" /> Confirming your payment…</p>}
        {state.phase === "paid" && (
          <>
            <CheckCircle2 className="text-emerald-400" size={32} />
            <h1 className="font-display text-3xl font-bold mt-5">Welcome to Vanta Plus</h1>
            <p className="text-zinc-400 mt-2 text-sm">Paste this key into Vanta Island → Settings → Vanta Plus.</p>
            <div className="mt-6 flex items-center justify-between rounded-xl border border-amber-400/40 bg-black px-4 py-3">
              <span data-testid="checkout-license-key-display" className="font-mono text-amber-400 tracking-wider">{state.key}</span>
              <button data-testid="checkout-copy-license-btn" onClick={() => { navigator.clipboard.writeText(state.key); toast.success("License copied"); }} className="text-zinc-400 hover:text-white"><Copy size={16} /></button>
            </div>
          </>
        )}
        {(state.phase === "failed" || state.phase === "timeout") && (
          <>
            <XCircle className="text-red-400" size={32} />
            <h1 className="font-display text-2xl font-bold mt-5">{state.phase === "failed" ? "Payment didn't go through" : "Still processing"}</h1>
            <p className="text-zinc-400 mt-2 text-sm">Refresh this page in a moment, or try again.</p>
          </>
        )}
        <Link to="/" data-testid="payment-back-home" className="mt-8 inline-block text-sm text-zinc-400 hover:text-white">← Back to Vanta Island</Link>
      </div>
    </Shell>
  );
}

export function PaymentCancel() {
  return (
    <Shell>
      <h1 className="font-display text-2xl font-bold">Checkout cancelled</h1>
      <p className="text-zinc-400 mt-2 text-sm">No charge was made. Everything except the extended wallpaper library stays free.</p>
      <Link to="/" data-testid="payment-cancel-back-home" className="mt-8 inline-block text-sm text-amber-400">← Back to Vanta Island</Link>
    </Shell>
  );
}
