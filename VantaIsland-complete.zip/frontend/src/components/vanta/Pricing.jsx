import { useState } from "react";
import { Check, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { startCheckout } from "@/lib/api";

const FREE = ["Full Dynamic Island", "Spotify & Apple Music controls", "Battery, weather, calendar", "Volume & brightness HUD", "Black pill & glass themes", "16 free animated wallpapers", "Import unlimited personal wallpapers"];
const PLUS = ["Everything in Free", "Full curated library (48+ loops)", "New wallpapers added over time", "Cancel anytime"];

export default function Pricing() {
  const [busy, setBusy] = useState(false);
  const go = async () => {
    setBusy(true);
    try { await startCheckout(); } catch { toast.error("Couldn't start checkout"); setBusy(false); }
  };
  return (
    <section id="pricing" className="py-28">
      <div className="max-w-5xl mx-auto px-6">
        <p className="text-xs font-semibold uppercase tracking-[0.2em] text-amber-400/90">Pricing</p>
        <h2 className="font-display text-3xl lg:text-5xl font-bold tracking-tight mt-3">Free forever. Plus if you want more wallpapers.</h2>
        <div className="mt-14 grid md:grid-cols-2 gap-5">
          <div data-testid="pricing-plan-free" className="rounded-3xl border border-white/[0.08] bg-[#0C0E12] p-8">
            <p className="font-display text-xl font-semibold">Vanta Island</p>
            <p className="mt-4"><span className="font-display text-5xl font-black">$0</span> <span className="text-zinc-500">forever</span></p>
            <ul className="mt-8 space-y-3 text-sm text-zinc-300">{FREE.map((f) => <li key={f} className="flex gap-3"><Check size={16} className="text-emerald-400 shrink-0" />{f}</li>)}</ul>
            <a href="#download" data-testid="pricing-free-download-btn" className="mt-10 block text-center rounded-full border border-white/15 py-3 font-semibold hover:border-white/40 transition-colors">Get the DMG</a>
          </div>
          <div data-testid="pricing-plan-plus" className="relative rounded-3xl border border-amber-400/40 bg-gradient-to-b from-amber-400/[0.07] to-[#0C0E12] p-8">
            <span className="absolute top-6 right-6 font-mono text-[10px] px-2 py-1 rounded-full bg-amber-400 text-black font-semibold">WALLPAPERS ONLY</span>
            <p className="font-display text-xl font-semibold">Vanta Plus</p>
            <p className="mt-4"><span className="font-display text-5xl font-black">$1.99</span> <span className="text-zinc-500">/ month</span></p>
            <ul className="mt-8 space-y-3 text-sm text-zinc-300">{PLUS.map((f) => <li key={f} className="flex gap-3"><Check size={16} className="text-amber-400 shrink-0" />{f}</li>)}</ul>
            <button onClick={go} disabled={busy} data-testid="pricing-upgrade-plus-btn"
              className="mt-10 w-full flex items-center justify-center gap-2 rounded-full bg-amber-400 text-black py-3 font-semibold hover:bg-amber-300 disabled:opacity-60 transition-colors">
              {busy && <Loader2 size={16} className="animate-spin" />} Subscribe with Stripe
            </button>
            <p className="text-[11px] text-zinc-500 mt-3 text-center">You'll get a license key to paste into the app.</p>
          </div>
        </div>
      </div>
    </section>
  );
}
