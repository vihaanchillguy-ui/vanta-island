import { Music2, BatteryCharging, CloudSun, CalendarDays, Volume2, Bell, Film, Palette } from "lucide-react";

const F = [
  { icon: Music2, t: "Spotify & Apple Music", d: "Artwork, track info, scrubbing progress and play / skip controls right from the island.", span: "md:col-span-2", tint: "text-emerald-400" },
  { icon: BatteryCharging, t: "Battery & charging", d: "Live percentage with a charging pulse when you plug in.", tint: "text-emerald-400" },
  { icon: CloudSun, t: "Weather", d: "Local conditions from Open-Meteo, no account needed.", tint: "text-amber-400" },
  { icon: CalendarDays, t: "Calendar", d: "Your next event, with a heads-up 10 minutes before it starts.", tint: "text-red-400" },
  { icon: Volume2, t: "Volume & brightness", d: "Elegant HUDs replace the clunky overlays.", tint: "text-cyan-400" },
  { icon: Bell, t: "Island notifications", d: "Track changes, charger, low battery and reminders slide out of the pill.", tint: "text-amber-400" },
  { icon: Film, t: "Always-animated wallpapers", d: "Video wallpapers keep looping continuously, even on battery. Import your own MP4, MOV or images.", span: "md:col-span-2", tint: "text-cyan-400" },
  { icon: Palette, t: "Black or glass", d: "Pure black pill by default, or a transparent glass theme.", tint: "text-zinc-200" },
];

export default function Features() {
  return (
    <section id="features" className="py-28">
      <div className="max-w-7xl mx-auto px-6">
        <p className="text-xs font-semibold uppercase tracking-[0.2em] text-amber-400/90">Everything in one pill</p>
        <h2 className="font-display text-3xl lg:text-5xl font-bold tracking-tight mt-3 max-w-2xl">Glanceable when you need it. Invisible when you don’t.</h2>
        <div className="mt-14 grid md:grid-cols-4 gap-4">
          {F.map(({ icon: I, t, d, span = "", tint }, i) => (
            <div key={t} data-testid={`feature-card-${i}`} className={`${span} group rounded-2xl border border-white/[0.08] bg-[#0C0E12] p-7 hover:border-white/20 hover:-translate-y-1 transition-[border-color,transform] duration-300`}>
              <I className={`${tint} mb-6`} size={22} />
              <h3 className="font-display text-lg font-semibold">{t}</h3>
              <p className="text-sm text-zinc-400 mt-2 leading-relaxed">{d}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
