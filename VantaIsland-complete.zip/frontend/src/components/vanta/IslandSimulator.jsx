import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Play, Pause, SkipBack, SkipForward, Zap, CloudSun, Calendar, Volume2, Sun } from "lucide-react";

const SIZES = {
  compact: { width: 230, height: 36, radius: 18 },
  music: { width: 400, height: 92, radius: 30 },
  battery: { width: 330, height: 52, radius: 26 },
  weather: { width: 380, height: 84, radius: 28 },
  volume: { width: 310, height: 44, radius: 22 },
};

const Bars = ({ color = "#10B981" }) => (
  <div className="flex items-end gap-[2px] h-3">
    {[0, 1, 2, 3].map((i) => (
      <span key={i} className="wave-bar w-[3px] h-full rounded-full" style={{ background: color, animationDelay: `${i * 0.15}s` }} />
    ))}
  </div>
);

function Music() {
  const [playing, setPlaying] = useState(true);
  const [pos, setPos] = useState(38);
  useEffect(() => {
    if (!playing) return;
    const t = setInterval(() => setPos((p) => (p >= 100 ? 0 : p + 0.5)), 200);
    return () => clearInterval(t);
  }, [playing]);
  return (
    <div className="flex items-center gap-3 w-full px-4">
      <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-rose-500 via-fuchsia-600 to-indigo-700 shrink-0" />
      <div className="flex-1 min-w-0">
        <div className="flex items-center justify-between">
          <p className="text-sm font-semibold truncate">Midnight City</p>
          <Bars />
        </div>
        <p className="text-xs text-zinc-400 truncate">M83 · Spotify</p>
        <input data-testid="island-music-scrubber" type="range" min="0" max="100" value={pos} onChange={(e) => setPos(+e.target.value)}
          className="w-full h-1 mt-2 accent-white cursor-pointer" />
      </div>
      <div className="flex items-center gap-3 shrink-0">
        <SkipBack size={15} className="cursor-pointer hover:scale-110 transition-transform" />
        <button data-testid="island-music-playpause" onClick={() => setPlaying(!playing)} className="hover:scale-110 transition-transform">
          {playing ? <Pause size={20} fill="white" /> : <Play size={20} fill="white" />}
        </button>
        <SkipForward size={15} className="cursor-pointer hover:scale-110 transition-transform" />
      </div>
    </div>
  );
}

const content = {
  compact: () => (
    <div className="flex items-center justify-between w-full px-3">
      <div className="w-5 h-5 rounded-md bg-gradient-to-br from-rose-500 to-indigo-700" />
      <div className="flex items-center gap-2"><Bars /><span className="text-[11px] font-semibold">98%</span></div>
    </div>
  ),
  music: Music,
  battery: () => (
    <div className="flex items-center justify-between w-full px-5">
      <div className="flex items-center gap-2"><Zap size={16} className="text-emerald-400 animate-pulse" fill="#10B981" />
        <span className="text-sm font-semibold">Charging</span></div>
      <span className="text-xs text-zinc-400">87% · 1h 12m to full</span>
    </div>
  ),
  weather: () => (
    <div className="grid grid-cols-2 gap-2 w-full px-3">
      <div className="rounded-2xl bg-white/[0.07] p-2.5 flex items-center gap-2"><CloudSun size={20} className="text-amber-400" />
        <div><p className="text-sm font-bold">22°</p><p className="text-[10px] text-zinc-400">Open-Meteo · Local</p></div></div>
      <div className="rounded-2xl bg-white/[0.07] p-2.5 flex items-center gap-2"><Calendar size={18} className="text-red-400" />
        <div className="min-w-0"><p className="text-xs font-semibold truncate">Design Review</p><p className="text-[10px] text-zinc-400">in 12 min</p></div></div>
    </div>
  ),
  volume: () => {
    const v = 62;
    return (
      <div className="flex items-center gap-3 w-full px-4">
        <Volume2 size={15} />
        <div className="flex-1 h-1.5 rounded-full bg-white/20 overflow-hidden"><div className="h-full bg-white rounded-full" style={{ width: `${v}%` }} /></div>
        <Sun size={14} className="text-zinc-400" />
      </div>
    );
  },
};

export default function IslandSimulator({ state, theme }) {
  const s = SIZES[state];
  const Content = content[state];
  return (
    <motion.div
      data-testid="hero-island-simulator"
      layout
      animate={{ width: s.width, height: s.height, borderRadius: s.radius }}
      transition={{ type: "spring", stiffness: 380, damping: 30 }}
      className={`${theme === "glass" ? "glass-pill" : "obsidian-pill"} flex items-center overflow-hidden text-white`}
    >
      <AnimatePresence mode="wait">
        <motion.div key={state} className="w-full flex items-center"
          initial={{ opacity: 0, scale: 0.92, filter: "blur(4px)" }} animate={{ opacity: 1, scale: 1, filter: "blur(0px)" }}
          exit={{ opacity: 0, scale: 0.92 }} transition={{ duration: 0.22 }}>
          <Content />
        </motion.div>
      </AnimatePresence>
    </motion.div>
  );
}
