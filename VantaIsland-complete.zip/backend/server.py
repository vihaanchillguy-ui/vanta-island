import asyncio
import os
import secrets
import logging
import shutil
from contextlib import suppress
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional, Literal

import httpx
import stripe
from dotenv import load_dotenv
from fastapi import FastAPI, APIRouter, HTTPException, Request, Header, Query
from fastapi.responses import FileResponse
from motor.motor_asyncio import AsyncIOMotorClient
from pydantic import BaseModel, Field
from pymongo import ASCENDING, IndexModel
from starlette.middleware.cors import CORSMiddleware

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / ".env")

from catalog import CATALOG  # noqa: E402

client = AsyncIOMotorClient(os.environ["MONGO_URL"])
db = client[os.environ["DB_NAME"]]
stripe.api_key = os.environ["STRIPE_SECRET_KEY"]
STRIPE_WEBHOOK_SECRET = os.environ["STRIPE_WEBHOOK_SECRET"]
TAX_MODE = "full"
PLUS_LOOKUP = "vanta_plus_monthly"
MACOS_DIR = Path("/app/macos")

INDEXES = {
    "payment_transactions": [IndexModel([("session_id", ASCENDING)], name="session_id", unique=True)],
    "licenses": [IndexModel([("key", ASCENDING)], name="key", unique=True)],
    "pexels_cache": [IndexModel([("category", ASCENDING)], name="category")],
}

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s")
logger = logging.getLogger(__name__)

app = FastAPI(title="Vanta Island API")
api = APIRouter(prefix="/api")


def now():
    return datetime.now(timezone.utc)


def setup_stripe_catalog():
    product = None
    for p in stripe.Product.list(active=True).auto_paging_iter():
        if p.to_dict().get("metadata", {}).get("emergent_product_id") == "vanta_plus":
            product = p
            break
    if not product:
        product = stripe.Product.create(
            name="Vanta Plus", tax_code="txcd_10302000",
            metadata={"managed_by": "emergent", "emergent_product_id": "vanta_plus"},
        )
    existing = stripe.Price.list(lookup_keys=[PLUS_LOOKUP], active=True, limit=1).data
    if existing and existing[0].unit_amount != 199:
        stripe.Price.modify(existing[0].id, active=False)
        existing = []
    if not existing:
        stripe.Price.create(product=product.id, unit_amount=199, currency="usd", lookup_key=PLUS_LOOKUP,
                            transfer_lookup_key=True, recurring={"interval": "month"})


async def is_valid_license(key: Optional[str]) -> bool:
    if not key:
        return False
    return await db.licenses.find_one({"key": key.strip().upper(), "active": True}) is not None


async def pexels_items(category: str):
    key = os.environ.get("PEXELS_API_KEY")
    if not key:
        return []
    cached = await db.pexels_cache.find_one({"category": category}, {"_id": 0})
    if cached and (now() - cached["created_at"].replace(tzinfo=timezone.utc)).total_seconds() < 3600:
        return cached["items"]
    try:
        async with httpx.AsyncClient(timeout=15) as c:
            r = await c.get("https://api.pexels.com/v1/videos/search", headers={"Authorization": key},
                            params={"query": category, "per_page": 15, "orientation": "landscape"})
        r.raise_for_status()
    except httpx.HTTPError as e:
        logger.warning("pexels failed: %s", e)
        return []
    items = []
    for v in r.json().get("videos", []):
        mp4 = [f for f in v.get("video_files", []) if f.get("file_type") == "video/mp4"]
        if not mp4:
            continue
        best = max(mp4, key=lambda f: (f.get("quality") == "hd", -abs((f.get("width") or 0) - 1920)))
        small = min(mp4, key=lambda f: f.get("width") or 9999)
        items.append({
            "id": f"px-{v['id']}", "title": f"{(v.get('user') or {}).get('name', 'Pexels')} · {category.title()}",
            "category": category, "premium": True, "preview_image": v["image"],
            "preview_video": small["link"], "video_url": best["link"], "source": "Pexels",
            "credit_url": v["url"],
        })
    await db.pexels_cache.update_one({"category": category}, {"$set": {"category": category, "items": items, "created_at": now()}}, upsert=True)
    return items


@api.get("/")
async def root():
    return {"app": "Vanta Island", "status": "ok"}


@api.get("/wallpapers")
async def list_wallpapers(
    category: Literal["all", "nature", "city", "space", "abstract"] = "all",
    license: Optional[str] = Query(None),
    x_vanta_license: Optional[str] = Header(None),
):
    unlocked = await is_valid_license(license or x_vanta_license)
    cats = ["nature", "city", "space", "abstract"] if category == "all" else [category]
    items = [w for w in CATALOG if w["category"] in cats]
    for c in cats:
        items += await pexels_items(c)
    out = []
    for w in items:
        locked = w["premium"] and not unlocked
        out.append({**w, "locked": locked, "video_url": None if locked else w["video_url"]})
    return {"unlocked": unlocked, "count": len(out), "items": out}


@api.get("/license/verify")
async def verify_license(key: str):
    return {"key": key.strip().upper(), "valid": await is_valid_license(key)}


class CheckoutRequest(BaseModel):
    origin_url: str
    email: Optional[str] = None


async def issue_license(session_id: str) -> str:
    tx = await db.payment_transactions.find_one({"session_id": session_id})
    if tx.get("license_key"):
        return tx["license_key"]
    key = "VANTA-" + "-".join(secrets.token_hex(2).upper() for _ in range(4))
    res = await db.payment_transactions.update_one(
        {"session_id": session_id, "license_key": {"$exists": False}}, {"$set": {"license_key": key}})
    if res.modified_count == 0:
        tx = await db.payment_transactions.find_one({"session_id": session_id})
        return tx["license_key"]
    await db.licenses.insert_one({"key": key, "session_id": session_id, "active": True, "created_at": now()})
    return key


async def mark_paid(session_id: str, s) -> None:
    await db.payment_transactions.update_one(
        {"session_id": session_id, "payment_status": {"$ne": "paid"}},
        {"$set": {"status": "completed", "payment_status": "paid",
                  "stripe_subscription_id": s.get("subscription"), "updated_at": now()}})
    await issue_license(session_id)


@api.post("/payments/checkout")
async def create_checkout(req: CheckoutRequest):
    prices = await asyncio.to_thread(lambda: stripe.Price.list(lookup_keys=[PLUS_LOOKUP], active=True, limit=1).data)
    if not prices:
        raise HTTPException(500, "Price not configured")
    price = prices[0]
    kwargs = dict(
        line_items=[{"price": price.id, "quantity": 1}], mode="subscription",
        success_url=f"{req.origin_url}/payment/success?session_id={{CHECKOUT_SESSION_ID}}",
        cancel_url=f"{req.origin_url}/payment/cancel",
        metadata={"lookup_key": PLUS_LOOKUP},
    )
    if req.email:
        kwargs["customer_email"] = req.email

    def create():
        try:
            return stripe.checkout.Session.create(**kwargs, managed_payments={"enabled": True})
        except stripe.error.InvalidRequestError as e:
            msg = (e.user_message or str(e)).lower()
            if "managed" in msg or "ineligible" in msg:
                return stripe.checkout.Session.create(**kwargs, automatic_tax={"enabled": True}, billing_address_collection="required")
            raise

    session = await asyncio.to_thread(create)
    await db.payment_transactions.insert_one({
        "session_id": session.id, "lookup_key": PLUS_LOOKUP, "amount": price.unit_amount / 100.0,
        "currency": price.currency, "status": "initiated", "payment_status": "pending",
        "created_at": now(), "updated_at": now(),
    })
    return {"checkout_url": session.url, "session_id": session.id}


@api.get("/payments/status/{session_id}")
async def payment_status(session_id: str):
    tx = await db.payment_transactions.find_one({"session_id": session_id})
    if not tx:
        raise HTTPException(404, "Transaction not found")
    if tx.get("payment_status") != "paid":
        try:
            s = await asyncio.to_thread(stripe.checkout.Session.retrieve, session_id)
            if s.payment_status == "paid" or s.status == "complete":
                await mark_paid(session_id, s)
        except stripe.error.StripeError:
            pass
        tx = await db.payment_transactions.find_one({"session_id": session_id})
    return {"session_id": tx["session_id"], "status": tx["status"], "payment_status": tx["payment_status"],
            "license_key": tx.get("license_key") if tx["payment_status"] == "paid" else None}


@api.post("/stripe/webhook")
async def stripe_webhook(request: Request):
    payload = await request.body()
    try:
        event = stripe.Webhook.construct_event(payload, request.headers.get("stripe-signature", ""), STRIPE_WEBHOOK_SECRET)
    except (stripe.error.SignatureVerificationError, ValueError):
        raise HTTPException(400, "Invalid signature")
    obj, t = event["data"]["object"], event["type"]
    if t in ("checkout.session.completed", "checkout.session.async_payment_succeeded"):
        if await db.payment_transactions.find_one({"session_id": obj["id"]}):
            await mark_paid(obj["id"], obj)
    elif t == "checkout.session.expired":
        await db.payment_transactions.update_one({"session_id": obj["id"]}, {"$set": {"status": "expired", "payment_status": "expired"}})
    elif t == "customer.subscription.deleted":
        tx = await db.payment_transactions.find_one({"stripe_subscription_id": obj["id"]})
        if tx and tx.get("license_key"):
            await db.licenses.update_one({"key": tx["license_key"]}, {"$set": {"active": False}})
    return {"status": "ok"}


@api.get("/download/source")
async def download_source():
    out = Path("/tmp/VantaIsland-macOS-source")
    archive = shutil.make_archive(str(out), "zip", root_dir=MACOS_DIR)
    return FileResponse(archive, filename="VantaIsland-macOS-source.zip", media_type="application/zip")


@api.get("/download/all")
async def download_all():
    import zipfile
    archive = "/tmp/VantaIsland-complete.zip"
    skip = {"node_modules", ".git", "__pycache__", "build", ".emergent", ".cache"}
    with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED) as z:
        for top in ["macos", "backend", "frontend"]:
            for p in Path("/app", top).rglob("*"):
                if p.is_file() and not skip & set(p.parts) and p.name != ".env":
                    z.write(p, p.relative_to("/app"))
        z.write("/app/memory/PRD.md", "PRD.md")
    return FileResponse(archive, filename="VantaIsland-complete.zip", media_type="application/zip")


app.include_router(api)
app.add_middleware(
    CORSMiddleware, allow_credentials=True,
    allow_origins=os.environ.get("CORS_ORIGINS", "*").split(","),
    allow_methods=["*"], allow_headers=["*"],
)


async def ensure_indexes():
    for coll, models in INDEXES.items():
        for m in models:
            try:
                await db[coll].create_indexes([m])
            except Exception as exc:
                logger.error("ensure_indexes(%s): %s", coll, exc)


@app.on_event("startup")
async def startup():
    app.state.index_task = asyncio.create_task(ensure_indexes())
    try:
        await asyncio.to_thread(setup_stripe_catalog)
    except stripe.error.StripeError as e:
        logger.error("stripe catalog setup failed: %s", e)


@app.on_event("shutdown")
async def shutdown():
    app.state.index_task.cancel()
    with suppress(asyncio.CancelledError):
        await app.state.index_task
    client.close()
