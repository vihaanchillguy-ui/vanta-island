FREE_PER_CATEGORY = 4

_RAW = {
    "nature": [
        (2213, "Emerald Canopy"), (41576, "Morning Valley"), (4075, "Tidal Glass"), (51585, "Golden Meadow"),
        (51502, "Alpine Breath"), (1186, "Silent Falls"), (51445, "Wild Coast"), (1173, "Moss Rain"),
        (50847, "Dune Drift"), (4881, "Lake Mirror"), (1780, "Fern Hollow"), (26108, "Cloud Ridge"),
    ],
    "city": [
        (49845, "Neon Avenue"), (49878, "Glass Towers"), (1606, "Midnight Grid"), (49846, "Skyline Pulse"),
        (4231, "Harbor Lights"), (34562, "Rush Hour"), (4332, "Concrete Dawn"), (4157, "Steel Horizon"),
        (4308, "Downtown Haze"), (3428, "Rooftop Glow"), (4067, "Bridge Traffic"), (4442, "Metro Bloom"),
    ],
    "space": [
        (18791, "Orbit Line"), (1610, "Starfield"), (45020, "Nebula Bloom"), (29351, "Event Horizon"),
        (14185, "Cosmic Dust"), (46119, "Deep Field"), (10418, "Solar Flare"), (14151, "Galactic Core"),
        (14540, "Pulsar"), (45033, "Ion Storm"), (39770, "Lunar Rise"), (4040, "Aurora Night"),
    ],
    "abstract": [
        (31497, "Liquid Chrome"), (31562, "Neon Flow"), (44818, "Prism Wave"), (14165, "Signal Drift"),
        (30, "Particle Field"), (32645, "Laser Grid"), (3524, "Ink Bloom"), (47282, "Holo Silk"),
        (22729, "Data Rain"), (44496, "Vapor Lines"), (4064, "Ember Mesh"), (2717, "Quantum Fold"),
    ],
}


def build_catalog():
    items = []
    for cat, rows in _RAW.items():
        for i, (vid, title) in enumerate(rows):
            items.append({
                "id": f"mk-{vid}",
                "title": title,
                "category": cat,
                "premium": i >= FREE_PER_CATEGORY,
                "preview_image": f"https://assets.mixkit.co/videos/{vid}/{vid}-thumb-720-0.jpg",
                "preview_video": f"https://assets.mixkit.co/videos/{vid}/{vid}-360.mp4",
                "video_url": f"https://assets.mixkit.co/videos/{vid}/{vid}-1080.mp4",
                "source": "Mixkit",
                "credit_url": "https://mixkit.co/free-stock-video/",
            })
    return items


CATALOG = build_catalog()
