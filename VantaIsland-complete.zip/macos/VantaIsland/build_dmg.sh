#!/bin/bash
# Builds Vanta Island.app and packages it into a DMG. Run on macOS 14+ with Xcode 15+.
set -euo pipefail
cd "$(dirname "$0")"

APP_NAME="Vanta Island"
VERSION="1.0.0"
BUILD_DIR="build"
APP="$BUILD_DIR/$APP_NAME.app"
DMG="$BUILD_DIR/VantaIsland-$VERSION.dmg"

echo "==> Compiling (universal: arm64 + x86_64)"
swift build -c release --arch arm64 --arch x86_64
BIN="$(swift build -c release --arch arm64 --arch x86_64 --show-bin-path)/VantaIsland"

echo "==> Assembling app bundle"
rm -rf "$BUILD_DIR" && mkdir -p "$APP/Contents/MacOS" "$APP/Contents/Resources"
cp "$BIN" "$APP/Contents/MacOS/VantaIsland"
cp Resources/Info.plist "$APP/Contents/Info.plist"

echo "==> Generating app icon"
ICONSET="$BUILD_DIR/AppIcon.iconset"
mkdir -p "$ICONSET"
sips -s format png Resources/AppIcon.jpg --out "$BUILD_DIR/icon_1024.png" >/dev/null
for s in 16 32 128 256 512; do
  sips -z $s $s "$BUILD_DIR/icon_1024.png" --out "$ICONSET/icon_${s}x${s}.png" >/dev/null
  sips -z $((s*2)) $((s*2)) "$BUILD_DIR/icon_1024.png" --out "$ICONSET/icon_${s}x${s}@2x.png" >/dev/null
done
iconutil -c icns "$ICONSET" -o "$APP/Contents/Resources/AppIcon.icns"

echo "==> Signing (ad-hoc; set SIGN_ID to use a Developer ID)"
codesign --force --deep --options runtime --sign "${SIGN_ID:--}" "$APP"

echo "==> Creating DMG"
STAGE="$BUILD_DIR/dmg"
mkdir -p "$STAGE"
cp -R "$APP" "$STAGE/"
ln -s /Applications "$STAGE/Applications"
hdiutil create -volname "$APP_NAME" -srcfolder "$STAGE" -ov -format UDZO "$DMG" >/dev/null
rm -rf "$STAGE" "$ICONSET"

echo "Done: $DMG"
echo "Open it, drag Vanta Island into Applications, then launch it."
