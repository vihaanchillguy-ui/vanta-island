# Vanta Island for macOS

A Dynamic Island for your Mac — black pill (default) or transparent glass — with music controls (Spotify & Apple Music), island notifications, battery/charging, weather (Open-Meteo), calendar, volume & brightness HUDs, and continuously animated live wallpapers with an online store.

## Build the DMG
Requirements: macOS 14 Sonoma or later, Xcode 15+ (or Command Line Tools with Swift 5.9+).

```bash
cd VantaIsland
chmod +x build_dmg.sh
./build_dmg.sh
```
Output: `build/VantaIsland-1.0.0.dmg`. Open it and drag **Vanta Island** to **Applications**.

Optional Developer ID signing: `SIGN_ID="Developer ID Application: Your Name (TEAMID)" ./build_dmg.sh`, then notarize with `xcrun notarytool submit build/VantaIsland-1.0.0.dmg --wait ...`.
Ad-hoc builds: first launch via right-click → Open (Gatekeeper).

To work in Xcode: `open Package.swift` and run the `VantaIsland` scheme.

## Permissions
- Automation (Spotify / Music) — prompted on first playback control.
- Calendar — next event in the expanded island.
- Location — local weather (falls back to Cupertino).

## Notes
- Notifications: the island shows its own notifications (track changes, charger plugged/unplugged, low battery, upcoming events within 10 minutes, wallpaper applied). macOS doesn't allow third-party apps to read other apps' notifications.
- Wallpapers live in `~/Library/Application Support/VantaIsland/Wallpapers`. They keep looping on battery (App Nap is disabled for playback).
- Vanta Plus license keys are entered in Settings → Vanta Plus.
