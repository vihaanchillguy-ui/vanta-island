import AppKit
import SwiftUI
import Combine

final class IslandPanel: NSPanel {
    override var canBecomeKey: Bool { true }
}

final class IslandPanelController {
    private let panel: IslandPanel
    private let model = IslandModel.shared
    private var monitors: [Any] = []
    private let size = NSSize(width: 560, height: 240)

    init() {
        panel = IslandPanel(contentRect: .zero, styleMask: [.borderless, .nonactivatingPanel],
                            backing: .buffered, defer: false)
        panel.isOpaque = false
        panel.backgroundColor = .clear
        panel.hasShadow = false
        panel.level = NSWindow.Level(rawValue: Int(CGWindowLevelForKey(.mainMenuWindow)) + 3)
        panel.collectionBehavior = [.canJoinAllSpaces, .stationary, .fullScreenAuxiliary, .ignoresCycle]
        panel.ignoresMouseEvents = true
        let root = IslandView()
            .environmentObject(model)
            .environmentObject(Prefs.shared)
            .environmentObject(MediaController.shared)
            .environmentObject(SystemMonitors.shared)
            .environmentObject(WeatherService.shared)
            .environmentObject(CalendarService.shared)
        let host = NSHostingView(rootView: root)
        host.frame = NSRect(origin: .zero, size: size)
        panel.contentView = host
        NotificationCenter.default.addObserver(forName: NSApplication.didChangeScreenParametersNotification,
                                               object: nil, queue: .main) { [weak self] _ in self?.position() }
    }

    func show() {
        position()
        panel.orderFrontRegardless()
        let handler: (NSEvent) -> Void = { [weak self] _ in self?.trackMouse() }
        if let g = NSEvent.addGlobalMonitorForEvents(matching: [.mouseMoved], handler: handler) { monitors.append(g) }
        if let l = NSEvent.addLocalMonitorForEvents(matching: [.mouseMoved], handler: { handler($0); return $0 }) { monitors.append(l) }
    }

    private func position() {
        guard let screen = NSScreen.main else { return }
        model.hasNotch = screen.safeAreaInsets.top > 0
        let f = screen.frame
        panel.setFrame(NSRect(x: f.midX - size.width / 2, y: f.maxY - size.height,
                              width: size.width, height: size.height), display: true)
    }

    private func trackMouse() {
        let p = NSEvent.mouseLocation
        let s = model.currentSize
        let f = panel.frame
        let rect = NSRect(x: f.midX - s.width / 2 - 8, y: f.maxY - s.height - 14, width: s.width + 16, height: s.height + 14)
        let inside = rect.contains(p)
        panel.ignoresMouseEvents = !inside
        model.hovering = inside
    }
}
