import SwiftUI

struct IslandNote: Equatable, Identifiable {
    let id = UUID()
    let icon: String
    let title: String
    let body: String
    var tint: Color = .white
}

enum IslandActivity: Equatable {
    case none
    case volume(Float, Bool)
    case brightness(Float)
    case charging(Int, Bool)
    case note(IslandNote)
}

final class IslandModel: ObservableObject {
    static let shared = IslandModel()

    @Published var expanded = false
    @Published var activity: IslandActivity = .none
    @Published var hasNotch = false
    @Published var hovering = false {
        didSet {
            guard hovering != oldValue else { return }
            if hovering && Prefs.shared.hoverToExpand { scheduleExpand() }
            if !hovering { collapseLater() }
        }
    }
    private var resetWork: DispatchWorkItem?
    private var expandWork: DispatchWorkItem?

    var currentSize: CGSize {
        if expanded { return CGSize(width: 460, height: 178) }
        switch activity {
        case .none: return CGSize(width: hasNotch ? 300 : 230, height: 34)
        case .volume, .brightness: return CGSize(width: 320, height: 40)
        case .charging: return CGSize(width: 340, height: 44)
        case .note: return CGSize(width: 380, height: 66)
        }
    }

    func toggle() { expanded.toggle() }

    func flash(_ a: IslandActivity, seconds: Double = 2.0) {
        guard !expanded else { return }
        if case .note = a, !Prefs.shared.showNotifications { return }
        activity = a
        resetWork?.cancel()
        let w = DispatchWorkItem { [weak self] in self?.activity = .none }
        resetWork = w
        DispatchQueue.main.asyncAfter(deadline: .now() + seconds, execute: w)
    }

    func notify(_ icon: String, _ title: String, _ body: String, tint: Color = .white) {
        flash(.note(IslandNote(icon: icon, title: title, body: body, tint: tint)), seconds: 3.5)
    }

    private func scheduleExpand() {
        expandWork?.cancel()
        let w = DispatchWorkItem { [weak self] in
            guard let self, self.hovering else { return }
            self.activity = .none
            self.expanded = true
        }
        expandWork = w
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.25, execute: w)
    }

    private func collapseLater() {
        expandWork?.cancel()
        DispatchQueue.main.asyncAfter(deadline: .now() + max(0.3, Prefs.shared.autoCollapse)) { [weak self] in
            guard let self, !self.hovering else { return }
            self.expanded = false
        }
    }
}
