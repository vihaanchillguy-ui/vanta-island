import SwiftUI
import AppKit

@main
struct VantaIslandApp: App {
    @NSApplicationDelegateAdaptor(AppDelegate.self) var delegate

    var body: some Scene {
        MenuBarExtra("Vanta Island", systemImage: "capsule.fill") {
            MenuContent()
                .environmentObject(Prefs.shared)
                .environmentObject(WallpaperStore.shared)
        }
        Window("Wallpaper Store", id: "store") {
            WallpaperStoreView()
                .environmentObject(Prefs.shared)
                .environmentObject(WallpaperStore.shared)
                .frame(minWidth: 980, minHeight: 640)
        }
        .windowStyle(.hiddenTitleBar)
        Settings {
            SettingsView()
                .environmentObject(Prefs.shared)
                .environmentObject(WallpaperStore.shared)
        }
    }
}

struct MenuContent: View {
    @EnvironmentObject var prefs: Prefs
    @Environment(\.openWindow) private var openWindow

    var body: some View {
        Button("Open Wallpaper Store…") {
            NSApp.activate(ignoringOtherApps: true)
            openWindow(id: "store")
        }
        Toggle("Animated Wallpaper", isOn: $prefs.wallpaperEnabled)
        Picker("Island Theme", selection: $prefs.theme) {
            Text("Black Pill").tag(IslandTheme.black)
            Text("Glass").tag(IslandTheme.glass)
        }
        Divider()
        SettingsLink { Text("Settings…") }.keyboardShortcut(",")
        Button("Quit Vanta Island") { NSApp.terminate(nil) }.keyboardShortcut("q")
    }
}

final class AppDelegate: NSObject, NSApplicationDelegate {
    var island: IslandPanelController?

    func applicationDidFinishLaunching(_ notification: Notification) {
        NSApp.setActivationPolicy(.accessory)
        island = IslandPanelController()
        island?.show()
        SystemMonitors.shared.start()
        MediaController.shared.start()
        WeatherService.shared.start()
        CalendarService.shared.start()
        WallpaperEngine.shared.start()
    }
}
