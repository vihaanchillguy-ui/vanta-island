import SwiftUI

struct SettingsView: View {
    var body: some View {
        TabView {
            AppearanceSettings().tabItem { Label("Appearance", systemImage: "paintpalette") }
            BehaviourSettings().tabItem { Label("Behaviour", systemImage: "slider.horizontal.3") }
            WallpaperSettings().tabItem { Label("Wallpaper", systemImage: "photo.on.rectangle") }
            LicenseSettings().tabItem { Label("Vanta Plus", systemImage: "star.circle") }
        }
        .frame(width: 520, height: 420)
    }
}

struct AppearanceSettings: View {
    @EnvironmentObject var prefs: Prefs
    var body: some View {
        Form {
            Picker("Island theme", selection: $prefs.theme) {
                Text("Black Pill (default)").tag(IslandTheme.black)
                Text("Transparent Glass").tag(IslandTheme.glass)
            }
            .pickerStyle(.radioGroup)
            Slider(value: $prefs.animationSpeed, in: 0.5...2) { Text("Animation speed") }
            Section("Show in island") {
                Toggle("Music (Spotify & Apple Music)", isOn: $prefs.showMusic)
                Toggle("Battery & charging", isOn: $prefs.showBattery)
                Toggle("Weather", isOn: $prefs.showWeather)
                Toggle("Calendar", isOn: $prefs.showCalendar)
                Toggle("Volume & brightness HUD", isOn: $prefs.showHUD)
                Toggle("Notifications", isOn: $prefs.showNotifications)
            }
            Toggle("Use Fahrenheit", isOn: $prefs.fahrenheit)
        }
        .formStyle(.grouped)
    }
}

struct BehaviourSettings: View {
    @EnvironmentObject var prefs: Prefs
    var body: some View {
        Form {
            Toggle("Expand on hover", isOn: $prefs.hoverToExpand)
            Slider(value: $prefs.autoCollapse, in: 0.5...6, step: 0.5) { Text("Collapse after \(prefs.autoCollapse, specifier: "%.1f")s") }
            Toggle("Launch at login", isOn: $prefs.launchAtLogin)
            Button("Preview notification") {
                IslandModel.shared.notify("bell.badge.fill", "Vanta Island", "This is how notifications appear.", tint: .yellow)
            }
        }
        .formStyle(.grouped)
    }
}

struct WallpaperSettings: View {
    @EnvironmentObject var prefs: Prefs
    @EnvironmentObject var store: WallpaperStore
    @Environment(\.openWindow) private var openWindow
    var body: some View {
        Form {
            Toggle("Animated wallpaper", isOn: $prefs.wallpaperEnabled)
            Toggle("Show on all displays", isOn: $prefs.allDisplays)
            Slider(value: $prefs.wallpaperRate, in: 0.25...1.5) { Text("Playback speed") }
            LabeledContent("Current", value: prefs.wallpaperPath.isEmpty ? "None" : URL(fileURLWithPath: prefs.wallpaperPath).lastPathComponent)
            Text("Wallpapers keep animating continuously, including on battery power.").font(.caption).foregroundStyle(.secondary)
            HStack {
                Button("Open Wallpaper Store…") { openWindow(id: "store") }
                Button("Import Personal Wallpaper…") { store.importPersonal() }
            }
        }
        .formStyle(.grouped)
    }
}

struct LicenseSettings: View {
    @EnvironmentObject var prefs: Prefs
    @EnvironmentObject var store: WallpaperStore
    @State private var key = ""
    @State private var status = ""
    var body: some View {
        Form {
            Text("Vanta Plus ($1.99/mo) only unlocks the extended wallpaper library. Everything else is free.")
                .font(.callout).foregroundStyle(.secondary)
            TextField("License key", text: $key, prompt: Text("VANTA-XXXX-XXXX-XXXX-XXXX"))
            HStack {
                Button("Activate") { Task { status = await store.verifyLicense(key) ? "Activated — enjoy Vanta Plus!" : "Invalid license key" } }
                Link("Get Vanta Plus", destination: URL(string: prefs.apiBase + "/#pricing")!)
            }
            if !status.isEmpty { Text(status).foregroundStyle(status.hasPrefix("Activated") ? .green : .red) }
            TextField("Library server", text: $prefs.apiBase)
        }
        .formStyle(.grouped)
        .onAppear { key = prefs.licenseKey }
    }
}
