import Foundation
import SwiftUI
import CoreLocation
import EventKit

final class WeatherService: NSObject, ObservableObject, CLLocationManagerDelegate {
    static let shared = WeatherService()
    @Published var temperatureText = "--°"
    @Published var symbol = "cloud.sun.fill"
    @Published var place = "Locating…"
    private let manager = CLLocationManager()
    private var coord = CLLocationCoordinate2D(latitude: 37.3349, longitude: -122.0090)
    private var timer: Timer?

    func start() {
        manager.delegate = self
        manager.desiredAccuracy = kCLLocationAccuracyKilometer
        manager.requestWhenInUseAuthorization()
        manager.requestLocation()
        timer = Timer.scheduledTimer(withTimeInterval: 900, repeats: true) { [weak self] _ in self?.refresh() }
        refresh()
    }

    func locationManager(_ m: CLLocationManager, didUpdateLocations locs: [CLLocation]) {
        guard let l = locs.last else { return }
        coord = l.coordinate
        CLGeocoder().reverseGeocodeLocation(l) { [weak self] p, _ in
            DispatchQueue.main.async { self?.place = p?.first?.locality ?? "Current location" }
        }
        refresh()
    }

    func locationManager(_ m: CLLocationManager, didFailWithError error: Error) {
        DispatchQueue.main.async { self.place = "Cupertino" }
    }

    func refresh() {
        let unit = Prefs.shared.fahrenheit ? "fahrenheit" : "celsius"
        let s = "https://api.open-meteo.com/v1/forecast?latitude=\(coord.latitude)&longitude=\(coord.longitude)&current=temperature_2m,weather_code,is_day&temperature_unit=\(unit)"
        guard let url = URL(string: s) else { return }
        URLSession.shared.dataTask(with: url) { [weak self] data, _, _ in
            guard let data, let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
                  let cur = json["current"] as? [String: Any] else { return }
            let t = (cur["temperature_2m"] as? Double) ?? 0
            let code = (cur["weather_code"] as? Int) ?? 0
            let day = ((cur["is_day"] as? Int) ?? 1) == 1
            DispatchQueue.main.async {
                self?.temperatureText = "\(Int(t.rounded()))°"
                self?.symbol = Self.symbol(code, day: day)
            }
        }.resume()
    }

    static func symbol(_ c: Int, day: Bool) -> String {
        switch c {
        case 0: return day ? "sun.max.fill" : "moon.stars.fill"
        case 1...3: return day ? "cloud.sun.fill" : "cloud.moon.fill"
        case 45, 48: return "cloud.fog.fill"
        case 51...67, 80...82: return "cloud.rain.fill"
        case 71...77, 85, 86: return "cloud.snow.fill"
        case 95...99: return "cloud.bolt.rain.fill"
        default: return "cloud.fill"
        }
    }
}

final class CalendarService: ObservableObject {
    static let shared = CalendarService()
    @Published var nextTitle = "No upcoming events"
    @Published var nextTime = "Today"
    private let store = EKEventStore()
    private var timer: Timer?
    private var notified = Set<String>()

    func start() {
        store.requestFullAccessToEvents { [weak self] granted, _ in
            guard granted else {
                DispatchQueue.main.async { self?.nextTitle = "Calendar access off"; self?.nextTime = "Enable in Settings" }
                return
            }
            DispatchQueue.main.async {
                self?.refresh()
                self?.timer = Timer.scheduledTimer(withTimeInterval: 60, repeats: true) { _ in self?.refresh() }
            }
        }
    }

    private func refresh() {
        let now = Date()
        let pred = store.predicateForEvents(withStart: now, end: now.addingTimeInterval(86400), calendars: nil)
        let next = store.events(matching: pred).filter { !$0.isAllDay }.sorted { $0.startDate < $1.startDate }.first
        guard let e = next else { nextTitle = "No upcoming events"; nextTime = "Next 24 hours"; return }
        nextTitle = e.title ?? "Event"
        let f = RelativeDateTimeFormatter()
        f.unitsStyle = .short
        nextTime = f.localizedString(for: e.startDate, relativeTo: now)
        let mins = e.startDate.timeIntervalSince(now) / 60
        if mins <= 10, mins > 0, let id = e.eventIdentifier, !notified.contains(id) {
            notified.insert(id)
            IslandModel.shared.notify("calendar.badge.clock", e.title ?? "Event", "Starts \(nextTime)", tint: .red)
        }
    }
}
