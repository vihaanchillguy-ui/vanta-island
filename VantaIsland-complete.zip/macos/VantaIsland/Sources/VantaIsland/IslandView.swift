import SwiftUI

struct IslandView: View {
    @EnvironmentObject var model: IslandModel
    @EnvironmentObject var prefs: Prefs

    var body: some View {
        let size = model.currentSize
        let radius: CGFloat = model.expanded ? 30 : size.height / 2
        VStack(spacing: 0) {
            ZStack {
                IslandBackground(theme: prefs.theme, radius: radius)
                content
                    .padding(.horizontal, model.expanded ? 18 : 12)
                    .transition(.opacity.combined(with: .scale(scale: 0.92)))
            }
            .frame(width: size.width, height: size.height)
            .clipShape(RoundedRectangle(cornerRadius: radius, style: .continuous))
            .shadow(color: .black.opacity(prefs.theme == .black ? 0.45 : 0.2), radius: model.expanded ? 18 : 6, y: 4)
            .padding(.top, model.hasNotch ? 0 : 6)
            .onTapGesture { model.toggle() }
            Spacer(minLength: 0)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .animation(.spring(response: 0.42 / max(prefs.animationSpeed, 0.2), dampingFraction: 0.78), value: model.expanded)
        .animation(.spring(response: 0.36 / max(prefs.animationSpeed, 0.2), dampingFraction: 0.8), value: model.activity)
        .preferredColorScheme(.dark)
    }

    @ViewBuilder var content: some View {
        if model.expanded {
            ExpandedIsland()
        } else {
            switch model.activity {
            case .none: CompactIsland()
            case .volume(let v, let muted): LevelHUD(icon: muted || v == 0 ? "speaker.slash.fill" : "speaker.wave.2.fill", value: muted ? 0 : v)
            case .brightness(let v): LevelHUD(icon: "sun.max.fill", value: v)
            case .charging(let pct, let plugged): ChargingToast(percent: pct, plugged: plugged)
            case .note(let n): NoteToast(note: n)
            }
        }
    }
}

struct IslandBackground: View {
    let theme: IslandTheme
    let radius: CGFloat
    var body: some View {
        let shape = RoundedRectangle(cornerRadius: radius, style: .continuous)
        if theme == .black {
            shape.fill(Color.black)
                .overlay(shape.strokeBorder(Color.white.opacity(0.06), lineWidth: 1))
        } else {
            shape.fill(.ultraThinMaterial)
                .overlay(shape.fill(Color.white.opacity(0.04)))
                .overlay(shape.strokeBorder(LinearGradient(colors: [.white.opacity(0.45), .white.opacity(0.08)],
                                                           startPoint: .top, endPoint: .bottom), lineWidth: 1))
        }
    }
}

struct CompactIsland: View {
    @EnvironmentObject var media: MediaController
    @EnvironmentObject var sys: SystemMonitors
    @EnvironmentObject var prefs: Prefs
    @EnvironmentObject var model: IslandModel

    var body: some View {
        HStack(spacing: 8) {
            if prefs.showMusic, let t = media.track {
                Artwork(url: t.artworkURL, size: 20)
                if !model.hasNotch {
                    Text(t.title).font(.system(size: 11, weight: .semibold)).lineLimit(1)
                }
            } else {
                Image(systemName: "sparkle").font(.system(size: 11, weight: .bold)).foregroundStyle(.white.opacity(0.7))
            }
            Spacer(minLength: model.hasNotch ? 120 : 6)
            if prefs.showMusic, media.track?.playing == true {
                Waveform().frame(width: 18, height: 12)
            }
            if prefs.showBattery { BatteryGlyph(percent: sys.batteryPercent, charging: sys.charging) }
        }
        .foregroundStyle(.white)
    }
}

struct ExpandedIsland: View {
    @EnvironmentObject var prefs: Prefs
    var body: some View {
        VStack(spacing: 12) {
            if prefs.showMusic { NowPlayingRow() }
            HStack(spacing: 10) {
                if prefs.showWeather { WeatherTile() }
                if prefs.showCalendar { CalendarTile() }
                if prefs.showBattery { BatteryTile() }
            }
        }
        .padding(.vertical, 14)
        .foregroundStyle(.white)
    }
}

struct NowPlayingRow: View {
    @EnvironmentObject var media: MediaController
    var body: some View {
        HStack(spacing: 12) {
            Artwork(url: media.track?.artworkURL, size: 46)
            VStack(alignment: .leading, spacing: 3) {
                Text(media.track?.title ?? "Nothing playing").font(.system(size: 13, weight: .semibold)).lineLimit(1)
                Text(media.track.map { "\($0.artist) · \($0.app.rawValue)" } ?? "Open Spotify or Apple Music")
                    .font(.system(size: 11)).foregroundStyle(.white.opacity(0.6)).lineLimit(1)
                ProgressView(value: media.track?.progress ?? 0).progressViewStyle(.linear).tint(.white).controlSize(.mini)
            }
            Spacer()
            HStack(spacing: 14) {
                IconButton("backward.fill") { media.previous() }
                IconButton(media.track?.playing == true ? "pause.fill" : "play.fill", size: 18) { media.playPause() }
                IconButton("forward.fill") { media.next() }
            }
        }
    }
}

struct IconButton: View {
    let name: String; let size: CGFloat; let action: () -> Void
    init(_ name: String, size: CGFloat = 13, action: @escaping () -> Void) { self.name = name; self.size = size; self.action = action }
    @State private var hover = false
    var body: some View {
        Button(action: action) {
            Image(systemName: name).font(.system(size: size, weight: .bold))
                .scaleEffect(hover ? 1.15 : 1).opacity(hover ? 1 : 0.85)
        }
        .buttonStyle(.plain)
        .onHover { h in withAnimation(.easeOut(duration: 0.15)) { hover = h } }
    }
}

struct Tile<Content: View>: View {
    @ViewBuilder let content: Content
    var body: some View {
        HStack(spacing: 8) { content }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(10)
            .background(RoundedRectangle(cornerRadius: 14, style: .continuous).fill(Color.white.opacity(0.07)))
    }
}

struct WeatherTile: View {
    @EnvironmentObject var weather: WeatherService
    var body: some View {
        Tile {
            Image(systemName: weather.symbol).font(.system(size: 18)).symbolRenderingMode(.multicolor)
            VStack(alignment: .leading, spacing: 1) {
                Text(weather.temperatureText).font(.system(size: 14, weight: .bold))
                Text(weather.place).font(.system(size: 10)).foregroundStyle(.white.opacity(0.55)).lineLimit(1)
            }
        }
    }
}

struct CalendarTile: View {
    @EnvironmentObject var cal: CalendarService
    var body: some View {
        Tile {
            Image(systemName: "calendar").font(.system(size: 16)).foregroundStyle(.red)
            VStack(alignment: .leading, spacing: 1) {
                Text(cal.nextTitle).font(.system(size: 11, weight: .semibold)).lineLimit(1)
                Text(cal.nextTime).font(.system(size: 10)).foregroundStyle(.white.opacity(0.55)).lineLimit(1)
            }
        }
    }
}

struct BatteryTile: View {
    @EnvironmentObject var sys: SystemMonitors
    var body: some View {
        Tile {
            BatteryGlyph(percent: sys.batteryPercent, charging: sys.charging)
            Text(sys.charging ? "Charging" : (sys.onAC ? "Power adapter" : "On battery"))
                .font(.system(size: 10)).foregroundStyle(.white.opacity(0.55))
        }
    }
}

struct BatteryGlyph: View {
    let percent: Int; let charging: Bool
    var color: Color { charging ? .green : (percent <= 20 ? .red : .white) }
    var body: some View {
        HStack(spacing: 4) {
            Text("\(percent)%").font(.system(size: 11, weight: .semibold)).monospacedDigit()
            ZStack(alignment: .leading) {
                RoundedRectangle(cornerRadius: 3).stroke(Color.white.opacity(0.5), lineWidth: 1).frame(width: 22, height: 11)
                RoundedRectangle(cornerRadius: 2).fill(color).frame(width: max(2, 18 * CGFloat(percent) / 100), height: 7).padding(.leading, 2)
                if charging { Image(systemName: "bolt.fill").font(.system(size: 7, weight: .black)).foregroundStyle(.black).frame(width: 22) }
            }
        }
    }
}

struct LevelHUD: View {
    let icon: String; let value: Float
    var body: some View {
        HStack(spacing: 10) {
            Image(systemName: icon).font(.system(size: 12, weight: .bold)).frame(width: 18)
            GeometryReader { g in
                ZStack(alignment: .leading) {
                    Capsule().fill(Color.white.opacity(0.18))
                    Capsule().fill(Color.white).frame(width: g.size.width * CGFloat(min(max(value, 0), 1)))
                }
            }
            .frame(height: 6)
            Text("\(Int(value * 100))").font(.system(size: 11, weight: .semibold)).monospacedDigit().frame(width: 26)
        }
        .foregroundStyle(.white)
    }
}

struct ChargingToast: View {
    let percent: Int; let plugged: Bool
    @State private var pulse = false
    var body: some View {
        HStack {
            Image(systemName: plugged ? "bolt.fill" : "powerplug")
                .foregroundStyle(plugged ? .green : .white)
                .scaleEffect(pulse ? 1.2 : 0.9)
                .onAppear { withAnimation(.easeInOut(duration: 0.8).repeatForever()) { pulse = true } }
            Text(plugged ? "Charging" : "Unplugged").font(.system(size: 12, weight: .semibold))
            Spacer()
            BatteryGlyph(percent: percent, charging: plugged)
        }
        .foregroundStyle(.white)
    }
}

struct NoteToast: View {
    let note: IslandNote
    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: note.icon).font(.system(size: 18, weight: .semibold)).foregroundStyle(note.tint)
                .frame(width: 36, height: 36).background(Circle().fill(Color.white.opacity(0.1)))
            VStack(alignment: .leading, spacing: 2) {
                Text(note.title).font(.system(size: 12, weight: .bold)).lineLimit(1)
                Text(note.body).font(.system(size: 11)).foregroundStyle(.white.opacity(0.65)).lineLimit(2)
            }
            Spacer()
        }
        .foregroundStyle(.white)
    }
}

struct Artwork: View {
    let url: URL?; let size: CGFloat
    var body: some View {
        AsyncImage(url: url) { img in img.resizable().scaledToFill() } placeholder: {
            ZStack { LinearGradient(colors: [.pink, .purple], startPoint: .topLeading, endPoint: .bottomTrailing)
                Image(systemName: "music.note").font(.system(size: size * 0.45, weight: .bold)) }
        }
        .frame(width: size, height: size)
        .clipShape(RoundedRectangle(cornerRadius: size * 0.25, style: .continuous))
    }
}

struct Waveform: View {
    var body: some View {
        TimelineView(.animation) { ctx in
            let t = ctx.date.timeIntervalSinceReferenceDate
            HStack(spacing: 2) {
                ForEach(0..<4, id: \.self) { i in
                    Capsule().fill(Color.green)
                        .frame(width: 2.5, height: 4 + 8 * abs(CGFloat(sin(t * 6 + Double(i) * 1.3))))
                }
            }
        }
    }
}
