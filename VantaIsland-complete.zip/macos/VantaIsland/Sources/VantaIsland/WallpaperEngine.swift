import AppKit
import AVFoundation
import UniformTypeIdentifiers

final class WallpaperEngine {
    static let shared = WallpaperEngine()
    private var windows: [NSWindow] = []
    private var loopers: [AVPlayerLooper] = []
    private var players: [AVQueuePlayer] = []
    private var activity: NSObjectProtocol?

    func start() {
        // Keep the wallpaper animating at full rate on battery and prevent App Nap throttling.
        activity = ProcessInfo.processInfo.beginActivity(options: [.userInitiatedAllowingIdleSystemSleep, .latencyCritical],
                                                         reason: "Continuous animated wallpaper")
        let nc = NSWorkspace.shared.notificationCenter
        nc.addObserver(forName: NSWorkspace.screensDidWakeNotification, object: nil, queue: .main) { [weak self] _ in self?.resume() }
        nc.addObserver(forName: NSWorkspace.activeSpaceDidChangeNotification, object: nil, queue: .main) { [weak self] _ in self?.resume() }
        NotificationCenter.default.addObserver(forName: NSApplication.didChangeScreenParametersNotification,
                                               object: nil, queue: .main) { [weak self] _ in self?.reload() }
        reload()
    }

    private func resume() { players.forEach { $0.play() } }

    func reload() {
        windows.forEach { $0.orderOut(nil) }
        windows.removeAll(); loopers.removeAll(); players.forEach { $0.pause() }; players.removeAll()
        let prefs = Prefs.shared
        guard prefs.wallpaperEnabled, !prefs.wallpaperPath.isEmpty,
              FileManager.default.fileExists(atPath: prefs.wallpaperPath) else { return }
        let url = URL(fileURLWithPath: prefs.wallpaperPath)
        let isImage = UTType(filenameExtension: url.pathExtension)?.conforms(to: .image) ?? false
        let screens = prefs.allDisplays ? NSScreen.screens : [NSScreen.main].compactMap { $0 }
        for screen in screens {
            let w = NSWindow(contentRect: screen.frame, styleMask: .borderless, backing: .buffered, defer: false, screen: screen)
            w.level = NSWindow.Level(rawValue: Int(CGWindowLevelForKey(.desktopWindow)))
            w.collectionBehavior = [.canJoinAllSpaces, .stationary, .ignoresCycle]
            w.ignoresMouseEvents = true
            w.isOpaque = true
            w.backgroundColor = .black
            w.setFrame(screen.frame, display: true)
            let view = NSView(frame: NSRect(origin: .zero, size: screen.frame.size))
            view.wantsLayer = true
            if isImage, let img = NSImage(contentsOf: url) {
                view.layer?.contents = img
                view.layer?.contentsGravity = .resizeAspectFill
            } else {
                let player = AVQueuePlayer()
                player.isMuted = true
                player.preventsDisplaySleepDuringVideoPlayback = false
                player.automaticallyWaitsToMinimizeStalling = false
                let looper = AVPlayerLooper(player: player, templateItem: AVPlayerItem(url: url))
                let layer = AVPlayerLayer(player: player)
                layer.videoGravity = .resizeAspectFill
                layer.frame = view.bounds
                layer.autoresizingMask = [.layerWidthSizable, .layerHeightSizable]
                view.layer?.addSublayer(layer)
                player.playImmediately(atRate: Float(prefs.wallpaperRate))
                players.append(player); loopers.append(looper)
            }
            w.contentView = view
            w.orderFrontRegardless()
            windows.append(w)
        }
    }
}
