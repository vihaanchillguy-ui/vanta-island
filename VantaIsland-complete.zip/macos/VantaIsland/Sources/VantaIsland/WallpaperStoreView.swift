import SwiftUI
import AVFoundation

let storeCategories: [(String, String, String)] = [
    ("all", "All", "square.grid.2x2"), ("nature", "Nature & Landscapes", "leaf"),
    ("city", "Cities & Architecture", "building.2"), ("space", "Space & Galaxies", "sparkles"),
    ("abstract", "Abstract & Futuristic", "circle.hexagongrid"), ("mine", "My Wallpapers", "folder"),
]

struct WallpaperStoreView: View {
    @EnvironmentObject var store: WallpaperStore
    @EnvironmentObject var prefs: Prefs
    @State private var category = "all"
    @State private var selected: RemoteWallpaper?

    var body: some View {
        NavigationSplitView {
            List(storeCategories, id: \.0, selection: $category) { c in
                Label(c.1, systemImage: c.2).tag(c.0)
            }
            .navigationSplitViewColumnWidth(min: 200, ideal: 220)
            .safeAreaInset(edge: .bottom) { PlusBadge().padding(12) }
        } detail: {
            VStack(spacing: 0) {
                header
                if category == "mine" { LocalGrid() } else { remoteGrid }
            }
            .background(Color(nsColor: .windowBackgroundColor))
        }
        .task(id: category) { if category != "mine" { await store.fetch(category: category) } }
        .sheet(item: $selected) { w in PreviewSheet(wallpaper: w) }
    }

    var header: some View {
        HStack {
            VStack(alignment: .leading, spacing: 2) {
                Text(storeCategories.first { $0.0 == category }?.1 ?? "").font(.system(size: 22, weight: .bold))
                Text("Live wallpapers loop continuously — even on battery.").font(.callout).foregroundStyle(.secondary)
            }
            Spacer()
            Button { store.importPersonal() } label: { Label("Import…", systemImage: "square.and.arrow.down") }
            Toggle("Enabled", isOn: $prefs.wallpaperEnabled).toggleStyle(.switch)
        }
        .padding(20)
    }

    var remoteGrid: some View {
        ScrollView {
            if let e = store.error { Text(e).foregroundStyle(.red).padding() }
            if store.loading && store.remote.isEmpty { ProgressView().padding(40) }
            LazyVGrid(columns: [GridItem(.adaptive(minimum: 240), spacing: 16)], spacing: 16) {
                ForEach(store.remote) { w in
                    WallpaperCard(wallpaper: w).onTapGesture { selected = w }
                }
            }
            .padding(20)
        }
    }
}

struct PlusBadge: View {
    @EnvironmentObject var store: WallpaperStore
    var body: some View {
        HStack {
            Image(systemName: store.unlocked ? "checkmark.seal.fill" : "lock.fill").foregroundStyle(store.unlocked ? .green : .orange)
            Text(store.unlocked ? "Vanta Plus active" : "Unlock all with Vanta Plus").font(.caption.weight(.semibold))
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(10)
        .background(RoundedRectangle(cornerRadius: 10).fill(.quaternary))
    }
}

struct WallpaperCard: View {
    let wallpaper: RemoteWallpaper
    @EnvironmentObject var store: WallpaperStore
    @State private var hover = false

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            ZStack {
                AsyncImage(url: URL(string: wallpaper.preview_image)) { $0.resizable().scaledToFill() } placeholder: { Color.black }
                if hover, let u = URL(string: wallpaper.preview_video) { LoopingVideo(url: u) }
                if wallpaper.locked {
                    Color.black.opacity(0.35)
                    Image(systemName: "lock.fill").font(.title2).foregroundStyle(.white)
                }
                if store.downloading.contains(wallpaper.id) { ProgressView().controlSize(.large) }
            }
            .aspectRatio(16 / 10, contentMode: .fit)
            .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
            .scaleEffect(hover ? 1.02 : 1)
            HStack {
                Text(wallpaper.title).font(.headline).lineLimit(1)
                Spacer()
                Text(wallpaper.premium ? "PLUS" : "FREE").font(.caption2.weight(.bold))
                    .padding(.horizontal, 6).padding(.vertical, 2)
                    .background(Capsule().fill(wallpaper.premium ? Color.orange.opacity(0.25) : Color.green.opacity(0.25)))
            }
        }
        .onHover { h in withAnimation(.easeOut(duration: 0.2)) { hover = h } }
    }
}

struct PreviewSheet: View {
    let wallpaper: RemoteWallpaper
    @EnvironmentObject var store: WallpaperStore
    @EnvironmentObject var prefs: Prefs
    @Environment(\.dismiss) var dismiss

    var body: some View {
        VStack(spacing: 16) {
            if let u = URL(string: wallpaper.video_url ?? wallpaper.preview_video) {
                LoopingVideo(url: u).aspectRatio(16 / 9, contentMode: .fit)
                    .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
            }
            HStack {
                VStack(alignment: .leading) {
                    Text(wallpaper.title).font(.title2.bold())
                    Text("\(wallpaper.category.capitalized) · \(wallpaper.source)").foregroundStyle(.secondary)
                }
                Spacer()
                Button("Close") { dismiss() }
                if wallpaper.locked {
                    Link("Get Vanta Plus", destination: URL(string: prefs.apiBase + "/#pricing")!).buttonStyle(.borderedProminent)
                } else {
                    Button {
                        Task { await store.apply(wallpaper); dismiss() }
                    } label: {
                        if store.downloading.contains(wallpaper.id) { ProgressView().controlSize(.small) } else { Text("Apply Wallpaper") }
                    }
                    .buttonStyle(.borderedProminent)
                }
            }
        }
        .padding(24)
        .frame(width: 760)
    }
}

struct LocalGrid: View {
    @EnvironmentObject var store: WallpaperStore
    @EnvironmentObject var prefs: Prefs
    var body: some View {
        ScrollView {
            if store.local.isEmpty {
                Text("No wallpapers yet. Apply one from the store or import your own video or image.")
                    .foregroundStyle(.secondary).padding(40)
            }
            LazyVGrid(columns: [GridItem(.adaptive(minimum: 240), spacing: 16)], spacing: 16) {
                ForEach(store.local) { w in
                    VStack(alignment: .leading) {
                        LoopingVideo(url: w.url).aspectRatio(16 / 10, contentMode: .fit)
                            .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
                            .overlay(RoundedRectangle(cornerRadius: 12).stroke(prefs.wallpaperPath == w.url.path ? Color.accentColor : .clear, lineWidth: 3))
                        HStack {
                            Text(w.name).lineLimit(1)
                            Spacer()
                            Button("Apply") { store.apply(local: w.url) }
                            Button(role: .destructive) { store.remove(w) } label: { Image(systemName: "trash") }
                        }
                    }
                }
            }
            .padding(20)
        }
    }
}

struct LoopingVideo: NSViewRepresentable {
    let url: URL
    func makeNSView(context: Context) -> PlayerView { PlayerView(url: url) }
    func updateNSView(_ v: PlayerView, context: Context) {}
}

final class PlayerView: NSView {
    private let player = AVQueuePlayer()
    private var looper: AVPlayerLooper?
    init(url: URL) {
        super.init(frame: .zero)
        wantsLayer = true
        let isImage = ["jpg", "jpeg", "png", "heic", "webp", "gif"].contains(url.pathExtension.lowercased())
        if isImage {
            layer?.contents = NSImage(contentsOf: url)
            layer?.contentsGravity = .resizeAspectFill
            return
        }
        player.isMuted = true
        looper = AVPlayerLooper(player: player, templateItem: AVPlayerItem(url: url))
        let pl = AVPlayerLayer(player: player)
        pl.videoGravity = .resizeAspectFill
        pl.autoresizingMask = [.layerWidthSizable, .layerHeightSizable]
        layer?.addSublayer(pl)
        player.play()
    }
    required init?(coder: NSCoder) { fatalError() }
    override func layout() { super.layout(); layer?.sublayers?.forEach { $0.frame = bounds } }
}
