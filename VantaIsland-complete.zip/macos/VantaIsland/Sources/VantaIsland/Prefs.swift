import Foundation
import ServiceManagement

enum IslandTheme: String, CaseIterable { case black, glass }

final class Prefs: ObservableObject {
    static let shared = Prefs()
    private let d = UserDefaults.standard

    @Published var theme: IslandTheme { didSet { d.set(theme.rawValue, forKey: "theme") } }
    @Published var hoverToExpand: Bool { didSet { d.set(hoverToExpand, forKey: "hoverToExpand") } }
    @Published var autoCollapse: Double { didSet { d.set(autoCollapse, forKey: "autoCollapse") } }
    @Published var showMusic: Bool { didSet { d.set(showMusic, forKey: "showMusic") } }
    @Published var showBattery: Bool { didSet { d.set(showBattery, forKey: "showBattery") } }
    @Published var showWeather: Bool { didSet { d.set(showWeather, forKey: "showWeather") } }
    @Published var showCalendar: Bool { didSet { d.set(showCalendar, forKey: "showCalendar") } }
    @Published var showHUD: Bool { didSet { d.set(showHUD, forKey: "showHUD") } }
    @Published var showNotifications: Bool { didSet { d.set(showNotifications, forKey: "showNotifications") } }
    @Published var fahrenheit: Bool { didSet { d.set(fahrenheit, forKey: "fahrenheit"); WeatherService.shared.refresh() } }
    @Published var animationSpeed: Double { didSet { d.set(animationSpeed, forKey: "animationSpeed") } }
    @Published var wallpaperEnabled: Bool { didSet { d.set(wallpaperEnabled, forKey: "wallpaperEnabled"); WallpaperEngine.shared.reload() } }
    @Published var wallpaperPath: String { didSet { d.set(wallpaperPath, forKey: "wallpaperPath"); WallpaperEngine.shared.reload() } }
    @Published var allDisplays: Bool { didSet { d.set(allDisplays, forKey: "allDisplays"); WallpaperEngine.shared.reload() } }
    @Published var wallpaperRate: Double { didSet { d.set(wallpaperRate, forKey: "wallpaperRate"); WallpaperEngine.shared.reload() } }
    @Published var apiBase: String { didSet { d.set(apiBase, forKey: "apiBase") } }
    @Published var licenseKey: String { didSet { d.set(licenseKey, forKey: "licenseKey") } }
    @Published var launchAtLogin: Bool {
        didSet {
            d.set(launchAtLogin, forKey: "launchAtLogin")
            try? launchAtLogin ? SMAppService.mainApp.register() : SMAppService.mainApp.unregister()
        }
    }

    private init() {
        d.register(defaults: [
            "theme": "black", "hoverToExpand": true, "autoCollapse": 2.5, "showMusic": true,
            "showBattery": true, "showWeather": true, "showCalendar": true, "showHUD": true,
            "showNotifications": true, "fahrenheit": false, "animationSpeed": 1.0,
            "wallpaperEnabled": true, "wallpaperPath": "", "allDisplays": true, "wallpaperRate": 1.0,
            "apiBase": "https://vanta-island-mac--1hwwq6d1.preview.emergentagent.com",
            "licenseKey": "", "launchAtLogin": false,
        ])
        theme = IslandTheme(rawValue: d.string(forKey: "theme") ?? "black") ?? .black
        hoverToExpand = d.bool(forKey: "hoverToExpand")
        autoCollapse = d.double(forKey: "autoCollapse")
        showMusic = d.bool(forKey: "showMusic")
        showBattery = d.bool(forKey: "showBattery")
        showWeather = d.bool(forKey: "showWeather")
        showCalendar = d.bool(forKey: "showCalendar")
        showHUD = d.bool(forKey: "showHUD")
        showNotifications = d.bool(forKey: "showNotifications")
        fahrenheit = d.bool(forKey: "fahrenheit")
        animationSpeed = d.double(forKey: "animationSpeed")
        wallpaperEnabled = d.bool(forKey: "wallpaperEnabled")
        wallpaperPath = d.string(forKey: "wallpaperPath") ?? ""
        allDisplays = d.bool(forKey: "allDisplays")
        wallpaperRate = d.double(forKey: "wallpaperRate")
        apiBase = d.string(forKey: "apiBase") ?? ""
        licenseKey = d.string(forKey: "licenseKey") ?? ""
        launchAtLogin = d.bool(forKey: "launchAtLogin")
    }
}
