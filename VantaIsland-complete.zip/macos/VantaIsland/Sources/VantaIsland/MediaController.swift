import Foundation
import SwiftUI
import AppKit

enum PlayerApp: String { case spotify = "Spotify", music = "Music" }

struct Track: Equatable {
    let app: PlayerApp
    let title: String
    let artist: String
    let artworkURL: URL?
    let playing: Bool
    let progress: Double
}

final class MediaController: ObservableObject {
    static let shared = MediaController()
    @Published var track: Track?
    private var timer: Timer?
    private var lastTitle = ""

    func start() {
        timer = Timer.scheduledTimer(withTimeInterval: 1.5, repeats: true) { [weak self] _ in self?.poll() }
        poll()
    }

    private func isRunning(_ app: PlayerApp) -> Bool {
        let id = app == .spotify ? "com.spotify.client" : "com.apple.Music"
        return !NSRunningApplication.runningApplications(withBundleIdentifier: id).isEmpty
    }

    private func run(_ source: String) -> String? {
        var err: NSDictionary?
        return NSAppleScript(source: source)?.executeAndReturnError(&err).stringValue
    }

    private func query(_ app: PlayerApp) -> Track? {
        guard isRunning(app) else { return nil }
        let art = app == .spotify ? "artwork url of current track" : "\"\""
        let dur = app == .spotify ? "(duration of current track) / 1000" : "duration of current track"
        let script = """
        tell application "\(app.rawValue)"
          if player state is stopped then return ""
          return (player state as string) & "||" & (name of current track) & "||" & (artist of current track) & "||" & \(art) & "||" & (player position as string) & "||" & (\(dur) as string)
        end tell
        """
        guard let out = run(script), !out.isEmpty else { return nil }
        let p = out.components(separatedBy: "||")
        guard p.count == 6 else { return nil }
        let pos = Double(p[4].replacingOccurrences(of: ",", with: ".")) ?? 0
        let total = Double(p[5].replacingOccurrences(of: ",", with: ".")) ?? 1
        return Track(app: app, title: p[1], artist: p[2], artworkURL: URL(string: p[3]),
                     playing: p[0] == "playing", progress: total > 0 ? min(pos / total, 1) : 0)
    }

    private func poll() {
        let s = query(.spotify)
        let m = query(.music)
        let t = [s, m].compactMap { $0 }.first(where: { $0.playing }) ?? s ?? m
        if t != track { track = t }
        if let t, t.playing, t.title != lastTitle {
            lastTitle = t.title
            IslandModel.shared.notify("music.note", t.title, "\(t.artist) · \(t.app.rawValue)", tint: t.app == .spotify ? .green : .pink)
        }
    }

    private func send(_ cmd: String) {
        guard let app = track?.app else { return }
        _ = run("tell application \"\(app.rawValue)\" to \(cmd)")
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) { self.poll() }
    }

    func playPause() { send("playpause") }
    func next() { send("next track") }
    func previous() { send("previous track") }
}
