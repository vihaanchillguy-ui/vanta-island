import Foundation
import IOKit.ps
import CoreAudio
import AudioToolbox
import Darwin
import CoreGraphics
import SwiftUI

final class SystemMonitors: ObservableObject {
    static let shared = SystemMonitors()
    @Published var batteryPercent = 100
    @Published var charging = false
    @Published var onAC = true

    private var timers: [Timer] = []
    private var lastBrightness: Float = -1
    private var lastVolume: Float = -1
    private var started = false
    private typealias BrightnessFn = @convention(c) (UInt32, UnsafeMutablePointer<Float>) -> Int32
    private var getBrightness: BrightnessFn?

    func start() {
        readBattery(initial: true)
        timers.append(Timer.scheduledTimer(withTimeInterval: 5, repeats: true) { [weak self] _ in self?.readBattery(initial: false) })
        setupVolume()
        if let h = dlopen("/System/Library/PrivateFrameworks/DisplayServices.framework/DisplayServices", RTLD_NOW),
           let sym = dlsym(h, "DisplayServicesGetBrightness") {
            getBrightness = unsafeBitCast(sym, to: BrightnessFn.self)
            timers.append(Timer.scheduledTimer(withTimeInterval: 0.4, repeats: true) { [weak self] _ in self?.readBrightness() })
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 1) { self.started = true }
    }

    private func readBattery(initial: Bool) {
        let snap = IOPSCopyPowerSourcesInfo().takeRetainedValue()
        let list = IOPSCopyPowerSourcesList(snap).takeRetainedValue() as [CFTypeRef]
        for ps in list {
            guard let d = IOPSGetPowerSourceDescription(snap, ps)?.takeUnretainedValue() as? [String: Any] else { continue }
            let pct = d[kIOPSCurrentCapacityKey] as? Int ?? 100
            let isCharging = d[kIOPSIsChargingKey] as? Bool ?? false
            let ac = (d[kIOPSPowerSourceStateKey] as? String) == kIOPSACPowerValue
            if !initial && ac != onAC { IslandModel.shared.flash(.charging(pct, ac), seconds: 3) }
            if !initial && pct == 20 && batteryPercent == 21 && !ac {
                IslandModel.shared.notify("battery.25", "Low Battery", "20% remaining. Connect your charger.", tint: .red)
            }
            batteryPercent = pct; charging = isCharging; onAC = ac
        }
    }

    private func readBrightness() {
        guard let fn = getBrightness else { return }
        var v: Float = 0
        guard fn(CGMainDisplayID(), &v) == 0 else { return }
        if lastBrightness >= 0, abs(v - lastBrightness) > 0.005, started, Prefs.shared.showHUD {
            IslandModel.shared.flash(.brightness(v), seconds: 1.5)
        }
        lastBrightness = v
    }

    private func outputDevice() -> AudioObjectID {
        var id = AudioObjectID(0)
        var size = UInt32(MemoryLayout<AudioObjectID>.size)
        var addr = AudioObjectPropertyAddress(mSelector: kAudioHardwarePropertyDefaultOutputDevice,
                                              mScope: kAudioObjectPropertyScopeGlobal, mElement: kAudioObjectPropertyElementMain)
        AudioObjectGetPropertyData(AudioObjectID(kAudioObjectSystemObject), &addr, 0, nil, &size, &id)
        return id
    }

    private func setupVolume() {
        let dev = outputDevice()
        var vAddr = AudioObjectPropertyAddress(mSelector: kAudioHardwareServiceDeviceProperty_VirtualMainVolume,
                                               mScope: kAudioDevicePropertyScopeOutput, mElement: kAudioObjectPropertyElementMain)
        var mAddr = AudioObjectPropertyAddress(mSelector: kAudioDevicePropertyMute,
                                               mScope: kAudioDevicePropertyScopeOutput, mElement: kAudioObjectPropertyElementMain)
        let block: AudioObjectPropertyListenerBlock = { [weak self] _, _ in self?.volumeChanged(dev) }
        AudioObjectAddPropertyListenerBlock(dev, &vAddr, DispatchQueue.main, block)
        AudioObjectAddPropertyListenerBlock(dev, &mAddr, DispatchQueue.main, block)
    }

    private func volumeChanged(_ dev: AudioObjectID) {
        var vol: Float32 = 0
        var size = UInt32(MemoryLayout<Float32>.size)
        var vAddr = AudioObjectPropertyAddress(mSelector: kAudioHardwareServiceDeviceProperty_VirtualMainVolume,
                                               mScope: kAudioDevicePropertyScopeOutput, mElement: kAudioObjectPropertyElementMain)
        AudioObjectGetPropertyData(dev, &vAddr, 0, nil, &size, &vol)
        var muted: UInt32 = 0
        var mSize = UInt32(MemoryLayout<UInt32>.size)
        var mAddr = AudioObjectPropertyAddress(mSelector: kAudioDevicePropertyMute,
                                               mScope: kAudioDevicePropertyScopeOutput, mElement: kAudioObjectPropertyElementMain)
        AudioObjectGetPropertyData(dev, &mAddr, 0, nil, &mSize, &muted)
        lastVolume = vol
        if Prefs.shared.showHUD { IslandModel.shared.flash(.volume(vol, muted != 0), seconds: 1.5) }
    }
}
