import Foundation
import SwiftUI
import AppKit
import UniformTypeIdentifiers

struct RemoteWallpaper: Codable, Identifiable, Hashable {
    let id: String
    let title: String
    let category: String
    let premium: Bool
    let locked: Bool
    let preview_image: String
    let preview_video: String
    let video_url: String?
    let source: String
}

struct WallpaperResponse: Codable { let unlocked: Bool; let items: [RemoteWallpaper] }

struct LocalWallpaper: Identifiable, Hashable {
    var id: String { url.path }
    let url: URL
    var name: String { url.deletingPathExtension().lastPathComponent }
}

final class WallpaperStore: ObservableObject {
    static let shared = WallpaperStore()
    @Published var remote: [RemoteWallpaper] = []
    @Published var local: [LocalWallpaper] = []
    @Published var unlocked = false
    @Published var loading = false
    @Published var error: String?
    @Published var downloading: Set<String> = []

    let folder: URL = {
        let base = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
        let f = base.appendingPathComponent("VantaIsland/Wallpapers", isDirectory: true)
        try? FileManager.default.createDirectory(at: f, withIntermediateDirectories: true)
        return f
    }()

    init() { scanLocal() }

    func scanLocal() {
        let files = (try? FileManager.default.contentsOfDirectory(at: folder, includingPropertiesForKeys: [.creationDateKey])) ?? []
        local = files.filter { !$0.lastPathComponent.hasPrefix(".") }.map(LocalWallpaper.init).sorted { $0.name < $1.name }
    }

    @MainActor
    func fetch(category: String = "all") async {
        let p = Prefs.shared
        var comps = URLComponents(string: p.apiBase + "/api/wallpapers")
        comps?.queryItems = [URLQueryItem(name: "category", value: category)]
        if !p.licenseKey.isEmpty { comps?.queryItems?.append(URLQueryItem(name: "license", value: p.licenseKey)) }
        guard let url = comps?.url else { return }
        loading = true; error = nil
        defer { loading = false }
        do {
            let (data, _) = try await URLSession.shared.data(from: url)
            let r = try JSONDecoder().decode(WallpaperResponse.self, from: data)
            remote = r.items; unlocked = r.unlocked
        } catch {
            self.error = "Couldn't reach the wallpaper library. Check your connection."
        }
    }

    @MainActor
    func verifyLicense(_ key: String) async -> Bool {
        let k = key.trimmingCharacters(in: .whitespaces).uppercased()
        guard let enc = k.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed),
              let url = URL(string: Prefs.shared.apiBase + "/api/license/verify?key=" + enc),
              let result = try? await URLSession.shared.data(from: url),
              let json = try? JSONSerialization.jsonObject(with: result.0) as? [String: Any] else { return false }
        let ok = json["valid"] as? Bool ?? false
        if ok { Prefs.shared.licenseKey = k; await fetch() }
        return ok
    }

    func localFile(for w: RemoteWallpaper) -> URL { folder.appendingPathComponent("\(w.title) (\(w.id)).mp4") }

    @MainActor
    func apply(_ w: RemoteWallpaper) async {
        let dest = localFile(for: w)
        if !FileManager.default.fileExists(atPath: dest.path) {
            guard let s = w.video_url, let url = URL(string: s) else { return }
            downloading.insert(w.id)
            defer { downloading.remove(w.id) }
            do {
                let (tmp, _) = try await URLSession.shared.download(from: url)
                try FileManager.default.moveItem(at: tmp, to: dest)
            } catch { self.error = "Download failed: \(error.localizedDescription)"; return }
            scanLocal()
        }
        apply(local: dest)
    }

    func apply(local url: URL) {
        Prefs.shared.wallpaperEnabled = true
        Prefs.shared.wallpaperPath = url.path
        IslandModel.shared.notify("photo.on.rectangle.angled", "Wallpaper applied", url.deletingPathExtension().lastPathComponent, tint: .cyan)
    }

    func importPersonal() {
        let panel = NSOpenPanel()
        panel.allowedContentTypes = [.movie, .mpeg4Movie, .quickTimeMovie, .image]
        panel.allowsMultipleSelection = true
        NSApp.activate(ignoringOtherApps: true)
        guard panel.runModal() == .OK else { return }
        for src in panel.urls {
            let dest = folder.appendingPathComponent(src.lastPathComponent)
            try? FileManager.default.copyItem(at: src, to: dest)
        }
        scanLocal()
        if let first = panel.urls.first { apply(local: folder.appendingPathComponent(first.lastPathComponent)) }
    }

    func remove(_ w: LocalWallpaper) {
        try? FileManager.default.trashItem(at: w.url, resultingItemURL: nil)
        if Prefs.shared.wallpaperPath == w.url.path { Prefs.shared.wallpaperPath = "" }
        scanLocal()
    }
}
