// swift-tools-version:5.9
import PackageDescription

let package = Package(
    name: "VantaIsland",
    platforms: [.macOS(.v14)],
    targets: [
        .executableTarget(name: "VantaIsland", path: "Sources/VantaIsland")
    ]
)
