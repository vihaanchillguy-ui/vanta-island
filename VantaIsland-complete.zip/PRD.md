# Vanta Island — PRD
## Original problem
Native macOS Dynamic Island app (black pill default + glass theme, expand animations, Spotify/Apple Music controls, notifications, battery/charging, weather, calendar, volume/brightness HUD) + continuously animated wallpapers (online store + personal import; nature, city, space, abstract), previews, settings, custom icon, DMG packaging.
## User choices
SwiftUI project + build_dmg.sh (built on user's Mac); free public video sources (Pexels key skipped -> curated Mixkit catalog, Pexels auto-added if PEXELS_API_KEY set); landing/download page + gallery; Open-Meteo; $1.99/mo Vanta Plus (Stripe sandbox, tax mode: Stripe manages everything) unlocks more wallpapers only.
## Architecture
- /app/macos/VantaIsland: Swift Package (macOS 14), Info.plist, AppIcon, build_dmg.sh (universal build, icns, ad-hoc sign, hdiutil DMG)
- Backend FastAPI: /api/wallpapers, /api/license/verify, /api/payments/checkout|status, /api/stripe/webhook, /api/download/source
- Frontend React landing: island simulator, features, gallery, pricing, download, payment success/cancel
## Implemented (2026-06)
All of the above; tested backend+frontend 100% (iteration_1). Swift not compiled (Linux env).
## Backlog
P1: verify Swift build on a Mac & fix compile issues; Pexels key for bigger library
P2: favorites/cloud sync, per-display wallpaper, notarization guide, hosted prebuilt DMG
